# Install Notes

This kit is written for a local AI coding workflow such as Codex or Claude
Desktop. It is intentionally tool-agnostic except for the optional Codex image
recovery script.

## Codex

1. Create a skill folder:

```bash
mkdir -p "$HOME/.codex/skills/visual-asset-integration"
```

2. Copy `SKILL.md` into that folder.

3. Copy the templates you want into the same folder or into your project docs.

4. If you use Codex image generation, put `recover_codex_imagegen.py` in your
   project:

```text
<project-root>/scripts/recover_codex_imagegen.py
```

5. After every generated image, run the recovery command from your project root
   and verify the copied file before editing or placing it.

## Claude Desktop

1. Add `SKILL.md` to your project instructions, Claude project knowledge, or
   preferred prompt library.
2. Add `anchor-map-template.md` and `asset-manifest-template.json` to the
   project.
3. When generating images, ask for one asset at a time and insist on durable
   files before you move to layout.
4. For icons and cutouts, generate on chroma-key green, then key out the
   background with your local image workflow.

## Recommended Project Folders

```text
project/
  docs/
    visual-anchor-map.md
    asset-plan.md
    qa-plan.md
  prompts/
    image-prompts.md
  manifests/
    asset-manifest.json
  assets/
    source-green/
    transparent/
    environment/
    proof/
  scripts/
    recover_codex_imagegen.py
```

