# Visual Anchor Map

| ID | Source | Region | Observation | Asset Role | Action | Verification |
| --- | --- | --- | --- | --- | --- | --- |
| Hero01 | intended layout or screenshot | top viewport | What is visible now | environment/editorial | generate/place/fix | desktop and mobile screenshot |
| Map01 | intended layout or screenshot | workflow section | What is visible now | editorial | generate/place/fix | screenshot and overflow check |
| CTA01 | intended layout or screenshot | download/action area | What is visible now | interface | generate/place/fix | link and keyboard check |

