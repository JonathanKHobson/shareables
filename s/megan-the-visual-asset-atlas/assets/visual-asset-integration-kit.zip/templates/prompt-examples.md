# Prompt Examples

## Hero Background

```text
Use case: stylized-concept
Asset type: public shareable hero environment background
Primary request: <scene that supports the first-screen message>
Composition/framing: wide landscape, generous safe text zone, detailed visual
interest away from important text
Constraints: no readable text, no logos, no watermark, no modern devices
```

## Chroma-Key Icon

```text
Use case: stylized-concept
Asset type: interface icon/cutout
Primary request: one <object> icon for <UI job>
Composition/framing: one centered object only, full object visible, ample margin
Background: solid chroma-key green #00ff00
Constraints: no text, no letters, no transparent background, no icon sheet
```

