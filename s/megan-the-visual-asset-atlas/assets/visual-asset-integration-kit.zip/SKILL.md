# Visual Asset Integration

Use this skill when a public artifact needs visuals that feel intentional
instead of generic: generated images, screenshots, proof artifacts, icons,
backgrounds, diagrams, textures, social previews, or decorative elements.

## Core Rule

Do not generate, pick, or place an asset until these are known:

- purpose
- source status
- placement
- crop behavior
- accessibility text
- verification path

## Source Labels

- `verified_source`: real artifact, screenshot, document, export, or public
  source that can support proof claims.
- `source_backed_derivative`: cropped or optimized from a real source without
  changing its meaning.
- `illustrative_generated`: AI-generated or staged visual used for mood,
  explanation, or interface personality. It does not prove a real event.
- `draft_or_pending`: not ready for public use.
- `unknown_source`: do not use as proof.

## Generated Asset Workflow

1. Define the asset job: evidence, identity, interface, environment, editorial,
   or atmosphere.
2. Assign an anchor: where the image belongs and what it must not collide with.
3. Write a prompt from placement needs, not just style vibes.
4. Generate one asset at a time.
5. Persist the generated file before using it.
6. Produce derivatives, such as cropped or transparent versions, from the
   recovered source.
7. Render the page and visually QA the anchors.

## Chroma-Key Icons And Cutouts

For icons, badges, props, portraits, and UI cutouts:

- Generate one object per image.
- Ask for a solid chroma-key green background: `#00ff00`.
- Do not ask the generator for transparency unless your generation tool writes
  a verified transparent file to disk.
- Remove the green background only after the generated source has been
  recovered and verified.
- Keep the green source and transparent derivative as separate files.

## Persistence Gate

If the image appears in chat but no file is saved, recover it from the Codex
thread rollout JSONL before using it.

```bash
python3 scripts/recover_codex_imagegen.py \
  --latest-only \
  --name-hint "<asset-slug>" \
  --copy-latest-to "<project-root>/.codex-outputs/images/<lane>/<asset-slug>_v01_<YYYYMMDD>_<HHMMSS>.png"
```

Then verify:

```bash
test -s "<absolute-path-to-image.png>"
/usr/bin/sips -g pixelWidth -g pixelHeight "<absolute-path-to-image.png>"
```

If recovery returns zero images, stop. Do not crop the chat preview, screenshot
the computer, substitute a web image, or use an SVG placeholder.

## Visual QA

Before publishing, check:

- desktop and mobile screenshots
- no horizontal overflow
- no clipped text
- no broken images
- readable contrast over backgrounds
- alt text on every image
- proof images near proof claims
- generated images never positioned as evidence

