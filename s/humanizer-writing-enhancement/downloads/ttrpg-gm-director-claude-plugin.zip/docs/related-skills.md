# Related Skills For TTRPG GM Director

This plugin uses canonical ownership. Skills listed here are intentionally not duplicated.

## creative-writing-studio
- `creative-project-router`
- `story-book-router`
- `story-architecture`

## media-io-toolkit
- `html-presentation-builder`
- `imagegen`
- `pdf`

## mcp-workbench
- `knowledge_atlas`
- `ttrpg_compass`
- `stargate_playtest_mcp`
- `safe-install-review`

## marketing-social-studio
- `communication-story-crafter`
- `social-content-studio`
