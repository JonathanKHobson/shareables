# TTRPG GM Director

Generated: 2026-07-22T06:15:07Z
Format: claude-code

GM roleplay, live table direction, TTRPG prep, Story Atlas, Daggerheart-aware teaching, safety, canon, and debrief skills.

## Skills

- `gm-roleplay-router`
- `live-table-director`
- `show-vs-tell-craft`
- `story-atlas-prep`
- `improv-roleplay-coach`
- `player-facilitator`
- `npc-performance-director`
- `pacing-scene-director`
- `rules-teaching-coach`
- `safety-accessibility-facilitator`
- `professional-public-gm`
- `debrief-canon-maintainer`
- `daggerheart-adapter`
- `personal-gm-style-adapter`
- `ttrpg-router`
- `creative-project-context`
- `story-architecture`
- `originality-rights-and-provenance`
- `publishing-router`
- `communication-story-crafter`
- `board-game-design`
- `game-designer`
- `visual-asset-integration`

## Related Plugins And Adjacent Skills

- `creative-writing-studio`: `creative-project-router`, `story-book-router`, `story-architecture`
- `media-io-toolkit`: `html-presentation-builder`, `imagegen`, `pdf`
- `mcp-workbench`: `knowledge_atlas`, `ttrpg_compass`, `stargate_playtest_mcp`, `safe-install-review`
- `marketing-social-studio`: `communication-story-crafter`, `social-content-studio`

## Adjacent MCP Keys

- `knowledge_atlas`
- `ttrpg_compass`
- `stargate_playtest_mcp`
- `p2p-gm-mcp`

MCP keys are documented adjacency, not automatic startup. This plugin does not
enable MCP servers by itself unless an `.mcp.json` is explicitly present.

## Starter Prompts

- Give me a live GM intervention card.
- Prep this one-shot for a public table.
- Debrief this session into canon-safe patches.

## Install Notes

- Claude Code: load the plugin root with `claude --plugin-dir <plugin-root>` or the generated zip.
- Codex: use the generated `.codex-plugin/plugin.json` bundle or the workspace marketplace export.
- Canonical skill sources remain outside this bundle. Rebuild from source rather than editing generated copies.
