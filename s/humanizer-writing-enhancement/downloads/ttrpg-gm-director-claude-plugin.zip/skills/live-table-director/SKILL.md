---
name: live-table-director
description: Give a human GM a compact, immediate TTRPG run card for pacing, spotlight, scene direction, player support, rules friction, safety edits, and next transitions during live play.
---

# Live Table Director

Use this skill when Kyle needs table-usable help in seconds, not an essay.
Return one recommended move, exact speakable words, one observable signal to
watch, one stop condition, and the likely next transition.

## Default Contract

Stay under 140 words unless Kyle explicitly asks for depth:

```text
CLOCK | SCENE | ENERGY | SPOTLIGHT
NOW:
SAY:
ASK:
WATCH:
CUT WHEN:
NEXT:
```

## Workflow

1. Orient to clock, scene purpose, energy, and recent spotlight.
2. Choose the highest-leverage, lowest-social-risk move.
3. Give exact GM language and at most one question.
4. Include a pass option when inviting a specific player.
5. Watch only observable behavior, not motives or diagnoses.
6. Set a cut/stop condition and likely next transition.
7. When description is needed, use the `show-vs-tell-craft` live card:
   `SHOW` one concrete detail/action/dialogue cue, `TELL` one plain
   clarification only if needed, `ASK` one player-contribution question, and
   `CUT` when the scene should move.

## Guardrails

- Preserve agency; offer bounded choices without hiding a forced outcome.
- Do not shame, label, diagnose, or mind-read players.
- Support brief answers, third-person narration, written responses, processing
  time, pass-and-return, and private check-ins.
- Teach only the rule needed for the current choice.
- Do not generate long literary prose in live play unless asked. Show one
  table-useful detail, then move.
- For Daggerheart or any system rule, label as official rule, temporary table
  ruling, or verify-after-play when source status is uncertain.
- If technology or retrieval competes with attention, use an analog fallback.
- Do not load the 225-file field guide wholesale during live play.

## References

- `references/live-output-contract.md`
- `references/observable-table-signals.md`
