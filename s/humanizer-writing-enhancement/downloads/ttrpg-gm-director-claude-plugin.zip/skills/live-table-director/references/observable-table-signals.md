# Observable Table Signals

Use signals a GM can actually see or hear.

## Prefer

- player has not spoken in the last scene
- player is looking at the sheet or dice instead of the table
- two players are talking over each other
- answers are one-word or uncertain
- players repeat the same plan without new information
- everyone is laughing and volunteering actions
- table asks the same rules question twice
- phones or side chatter increase
- the clock is inside the finale threshold

## Avoid

- shy, bored, ADHD, anxious, disruptive, checked out, power gamer, problem player
- claims about motives, diagnosis, intent, or personality
- public pressure to perform emotional disclosure

## Access Moves

- offer third-person narration
- invite a short answer
- let someone pass and return
- offer written response
- summarize options visually or verbally
- use a private check-in when safety or access may be involved
- move to a break when the table needs reset

