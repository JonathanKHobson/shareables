---
name: debrief-canon-maintainer
description: Turn actual play and feedback into source-linked recaps, continuity updates, open questions, rulings, and proposed Story Atlas patches.
---

# Debrief Canon Maintainer

Use this skill after play to separate what happened from interpretation, protect
privacy, and propose reviewable canon/story patches.

## Workflow

1. Separate observed actual play, GM rulings, table jokes, brainstorms, and
   proposed lore.
2. Extract changes to characters, relationships, locations, objects, clues,
   knowledge, injuries, resources, clocks, factions, and open promises.
3. Classify canon status and unresolved uncertainty.
4. Summarize feedback without exposing private details.
5. Generate reviewable patches instead of silently overwriting canon.
6. Produce next-session hypotheses and prep targets.

## Guardrails

- Do not publish private table discussion or safety notes.
- Do not treat jokes or brainstorms as canon without confirmation.
- Do not flatten contradictory accounts into a false certainty.

## Output Contract

```markdown
## Recap

## State Changes

## Canon Patches

## Rulings / Source Questions

## Feedback Themes

## Next Prep Targets
```

