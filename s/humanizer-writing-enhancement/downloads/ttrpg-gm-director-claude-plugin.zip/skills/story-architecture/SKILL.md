---
name: story-architecture
description: Develop or evaluate premise, theme, story promise, plot structure, character arcs, scenes, chapters, POV, pacing, clue logic, setup/payoff, mystery, continuity, and deliberate ambiguity for fiction, books, screenplays, interactive stories, and narrative games.
---

# Story Architecture

Use this skill when the story itself needs shaping or diagnosis. The output should make the next writing decision easier, not bury the user in theory.

## Inputs

Gather only what matters:

- Story promise, genre, audience, format, and intended emotional experience.
- Current stage: premise, outline, draft, revision, continuity repair, or adaptation.
- POV/tense, protagonist, antagonist/pressure, central conflict, stakes, constraints.
- Known canon, timeline, open questions, and deliberate mysteries.

## Architecture Checks

- Promise: does the premise tell the reader what kind of satisfaction is coming?
- Causality: do events happen because of character choices, pressure, and consequences?
- Agency: who chooses, who pays, who changes?
- Stakes: what becomes harder, better, worse, or irreversible?
- Scene purpose: what changes by the end of each scene?
- Show/tell purpose: what must be dramatized, what can be summarized, and what
  concrete evidence lets the reader infer the emotional or thematic point?
- Arc pressure: how does each plot or character arc advance, pause, or transform?
- Setup/payoff: what is planted, what is paid off, what is still a promise?
- Clue logic: are necessary clues available, redundant, and fair?
- Pacing: where does the reader need speed, friction, relief, or reflection?
- Line support: use `show-vs-tell-craft` when a scene review finds flat
  emotional labels, unsupported claims, unclear clues, or over-described
  transitions.
- Voice/POV: does the narration know only what it can know?

## Continuity Triage

Label findings precisely:

- hard contradiction
- likely contradiction
- unresolved question
- deliberate mystery
- deliberate unreliable account
- flashback or flash-forward
- alternate continuity
- draft placeholder
- authorial choice

Do not "fix" ambiguity that is deliberately marked. Ask for author choice when a fix would change theme, voice, canon, or reader interpretation.

## Output Shapes

### Story Diagnosis

```markdown
## Diagnosis
- Promise:
- Main pressure:
- Strongest engine:
- Main structural risk:

## Findings
1. Issue:
   - Evidence:
   - Why it matters:
   - Fix options:

## Author Choices

## Next Revision
```

### Outline / Beat Sheet

```markdown
## Story Spine
- Desire:
- Pressure:
- Cost:
- Turn:
- Consequence:
- Payoff:

## Beats
| Beat | Purpose | Character Change | State Change | Setup/Payoff |
| --- | --- | --- | --- | --- |
```
