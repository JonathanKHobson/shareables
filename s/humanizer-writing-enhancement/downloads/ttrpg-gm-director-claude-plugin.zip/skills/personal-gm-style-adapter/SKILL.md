---
name: personal-gm-style-adapter
description: Apply a removable personal GM-style adapter: embodied recurring NPCs, relational roleplay, bright satire, diegetic media, campfire questions, callbacks, and guardrails for pacing, lore, rules, puzzles, tech, and feedback.
---

# Personal GM Style Adapter

Use this skill only as an optional style layer after factual, safety, source, and
agency constraints are already satisfied.

## Strengths To Preserve

- embodied recurring NPCs
- relational roleplay and collaborative character history
- bright satire with dystopia in the details
- diegetic media and world framing
- campfire questions and emotional texture
- player callbacks and theatrical table energy

## Guardrails

- NPC tunnel timer: name the exit condition before indulging the performance.
- Scene-purpose check: every flourish should advance pressure, choice, clue, or
  relationship.
- Lore bandwidth budget: one vivid detail now, deeper lore after player pull.
- Finale threshold: protect the ending before adding another texture layer.
- Spotlight scan: style cannot replace player turns.
- Rules-confidence label: do not let performance hide uncertainty.
- Puzzle-legibility test: make the actionable signal visible.
- Tech fallback: switch to analog when media competes with attention.
- Feedback reflection before defending design intent.

## Output Contract

```markdown
## Neutral Core

## Personal Style Layer

## Triggered Guardrails

## Remove-This-Layer Version
```
