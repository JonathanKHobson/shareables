# TTRPG Application

Player-facing prose and GM-facing notes have different jobs.

## Player-Facing Description

Purpose: make players feel the place, creature, NPC, object, or threat.

Rules:

- Describe before naming.
- Use concrete sensory and interactable details.
- Do not explain the plot.
- Do not tell players what emotion to feel.
- Do not reveal GM-only secrets.
- Let players infer danger, sadness, corruption, awe, or humor from evidence.
- Keep it short enough to read aloud.

## GM Sidebar

Purpose: tell clearly.

Rules:

- Explain function, tone, pacing role, and real-world comparison.
- Use plain language.
- Tell the GM what this resembles.
- Give usable table guidance.
- Do not become poetic.
- Do not repeat the player-facing prose.

## Live Table Card

For live GM use, keep the output short:

```markdown
SHOW:
One concrete detail, action, or dialogue cue.

TELL:
One plain GM clarification if needed.

ASK:
One question that lets the player contribute showing.

CUT:
When to stop the scene and move forward.
```

## Safety, Rules, And Access

Tell plainly for safety reminders, rules teaching, table procedure, and direct
accessibility support. Do not dramatize what should be clear, consent-based, or
quickly usable.

