# Examples

## Fear

Telling:

```text
The girl was scared of the wilderness.
```

Showing:

```text
Every branch-snap turned her head. She kept one hand on the tree trunks as she walked, as if the forest might tilt without warning.
```

## Corporate Shrine

Telling:

```text
The shrine was corrupted by capitalism.
```

Showing:

```text
Candles burned behind locked glass. A brass placard read: ONE PRAYER PER TOKEN. Beneath the saint's smile, a clerk counted coins into a velvet bag.
```

GM sidebar:

```text
This should feel like sacred space processed through a payment kiosk. Keep the tone bright and absurd, but let one wrong detail reveal the cruelty.
```

## Nervous NPC

Telling:

```text
The clerk was nervous.
```

Showing:

```text
The clerk stamped the same form three times, missed the ink pad twice, and smiled at the party without showing teeth.
```

## When Telling Is Better

Bad over-showing:

```text
He approached the rectangular wooden barrier, grasped the cold metal sphere attached to it, rotated the sphere, and pulled.
```

Better telling:

```text
He opened the door.
```

## Blend

```text
Everyone knew Hexmart potions were unreliable. The healing vial hissed when uncorked, belched pink smoke, and whispered "probably" before she drank it.
```

## Body Language

Weak showing:

```text
His fists clenched. His jaw tightened. His heart pounded.
```

Better showing:

```text
He folded the pardon in half, then in half again, until the queen's seal split down the middle.
```

## Dialogue

Telling:

```text
She said angrily that Bob had betrayed her.
```

Showing:

```text
She set Bob's ring on the table. "Keep it. It already learned how to leave."
```

