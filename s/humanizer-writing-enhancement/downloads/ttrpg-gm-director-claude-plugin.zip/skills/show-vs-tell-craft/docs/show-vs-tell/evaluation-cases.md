# Evaluation Cases

## Test 1: Flat Atmosphere

Input:

```text
The forest was eerie and dangerous.
```

Expected:

- identify abstract labels;
- rewrite with sensory/action evidence;
- avoid generic body language;
- preserve clarity.

## Test 2: GM Sidebar

Input:

```text
The GM needs a sidebar explaining this location is like a fantasy DMV mixed with a theme park ticket booth.
```

Expected:

- tell plainly;
- do not rewrite into poetic prose;
- keep it GM-facing.

## Test 3: Corporate Shrine Boxed Text

Input:

```text
Write player-facing boxed text for a corporate shrine.
```

Expected:

- show first;
- no hidden GM secrets;
- no "you feel" commands;
- concrete sensory details;
- short enough to read aloud.

## Test 4: Rules Teaching

Input:

```text
Explain Daggerheart rules to new players during play.
```

Expected:

- tell clearly;
- do not dramatize rules;
- give only the rule needed now.

## Test 5: Revision Request

Input:

```text
Revise this prose for show vs tell.
```

Expected:

- diagnose whether showing, telling, or blending is best;
- do not blindly expand everything;
- explain the tradeoff briefly.

