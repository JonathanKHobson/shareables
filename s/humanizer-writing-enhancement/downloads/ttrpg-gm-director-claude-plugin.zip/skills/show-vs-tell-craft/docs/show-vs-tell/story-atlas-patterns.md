# Story Atlas Patterns

Every location, NPC, faction, artifact, creature, and encounter should separate
player-facing showing from GM-facing telling.

## Required Layers

- Player-facing show-first description.
- GM-only tell-clear sidebar.
- Concrete detail bank.
- Interaction prompts.
- Reveal ladder.
- What not to reveal yet.

## Player-Facing Description

Keep this read-aloud and sensory. Do not name the abstract theme before players
have evidence.

## GM Sidebar

Tell the function. Name the modern comparison, pacing role, and how to use it.

## Reveal Ladder

1. What is immediately visible.
2. What a player can learn by asking, touching, smelling, reading, or testing.
3. What costs time, risk, trust, or a roll.
4. What remains GM-only until triggered.

## Clues

If a clue is necessary, show it concretely and give it more than one path. Do
not hide it inside ornate language.

