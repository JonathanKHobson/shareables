# Decision Table

| Need | Use | Reason |
| --- | --- | --- |
| The audience should feel the moment | Show | Immersion, memory, emotion, atmosphere |
| The audience needs orientation fast | Tell | Clarity and pace beat texture |
| A broad claim needs proof | Blend | Telling frames; showing proves |
| A rule, safety note, or table procedure matters | Tell | Utility and accessibility |
| A clue must be fair | Show plus redundancy | Players need concrete, actionable evidence |
| A transition is routine | Tell | Showing would waste time |
| A character trait matters | Show | Behavior, dialogue, and choices carry personality |
| Narrative voice makes summary enjoyable | Tell or blend | Strong telling can be artful |
| Prose becomes purple or slow | Tell or compress | Clarity and action need room |
| Player-facing boxed text | Show first | Let players infer tone without GM secrets |
| GM sidebar | Tell clearly | The GM needs function, analogy, and use |

## Two Plus Two

Do not give the audience four when two plus two is enough. Provide concrete
evidence and let the audience infer the obvious conclusion. In TTRPGs, do not
turn this into unfair obscurity: necessary clues must be concrete, redundant,
and actionable.

