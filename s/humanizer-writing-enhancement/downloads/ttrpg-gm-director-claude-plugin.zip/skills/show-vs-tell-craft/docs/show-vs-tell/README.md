# Show vs Tell Craft

The revised rule is **show, don't just tell**.

Showing dramatizes. Telling summarizes. Good prose uses both as tools for pace,
immersion, clarity, utility, and emotional focus.

## What Showing Does

Showing gives the audience concrete evidence so they infer meaning. It uses
action, objects, sensory detail, dialogue, subtext, cause and effect, POV,
contrast, motif, and interactable detail.

## What Telling Does

Telling names, compresses, or clarifies. It can carry voice, wit, mythic
cadence, fairy-tale clarity, transition, table procedure, rules teaching, or an
emotional summary after enough evidence has been dramatized.

## What The System Should Stop Doing

- Do not treat showing as "make everything longer and more flowery."
- Do not ban exposition.
- Do not turn every sentence into sensory description.
- Do not hide actionable information from players.
- Do not refuse simple nouns like door, sword, car, contract, or frog.

## Preferred Pattern

Tell the organizing idea when useful, then immediately show proof:

```text
Everyone knew Hexmart potions were unreliable. The healing vial hissed when uncorked, belched pink smoke, and whispered "probably" before she drank it.
```

