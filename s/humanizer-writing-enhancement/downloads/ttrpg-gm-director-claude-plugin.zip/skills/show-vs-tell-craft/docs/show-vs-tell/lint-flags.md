# Lint Flags

These are review signals, not banned words.

## Weak Telling Signals

- Emotion labels with no evidence: scared, angry, sad, happy, nervous.
- Atmosphere labels with no evidence: intimidating, eerie, majestic, beautiful,
  strange.
- `was` plus adjective when the moment should be felt.
- `felt` plus emotion or atmosphere.
- `seemed` as a hedge when an image can prove the point.
- `the players feel/notice/realize/understand` when evidence can do the work.
- "This place is important" instead of visible signs of importance.
- "The NPC is kind" instead of kind behavior.
- "The villain is cruel" instead of a cruel choice.
- "The market is bustling" instead of motion, noise, smells, and exchanges.
- "As you know" exposition.
- Lore dumps inserted into dialogue for reader benefit.
- Generic body language loops: clenched fists, pounding heart, racing pulse,
  shiver down spine, narrowed eyes, crossed arms.
- Judging adjectives: grand, impressive, horrible, terrifying, suspicious,
  charming, chaotic, cozy.

## Over-Showing Signals

- The passage becomes bloated.
- Obvious objects are described instead of named.
- The prose refuses to say door, sword, car, frog, or contract.
- Description delays action too long.
- Figurative language becomes tangled.
- Body language substitutes for actual psychology or choice.
- The scene becomes purple prose.
- The GM cannot read it aloud comfortably.
- The player cannot tell what is actionable.
- The passage hides information players need to choose.

