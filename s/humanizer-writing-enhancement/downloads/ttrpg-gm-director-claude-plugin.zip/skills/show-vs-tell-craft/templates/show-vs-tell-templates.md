# Show vs Tell Templates

## Show vs Tell Diagnosis

```markdown
## Show vs Tell Diagnosis

### Passage Purpose
- Audience:
- Mode:
- Should this be felt, understood, or both?

### Current Balance
- Showing:
- Telling:
- Problem:

### Lint Flags
- Abstract labels:
- Unsupported claims:
- Generic body language:
- Reader-benefit exposition:
- Missing sensory/action evidence:

### Recommendation
- Show:
- Tell:
- Blend:

### Revision
```

## Story Atlas Description

```markdown
## Player-Facing Description
Short, concrete, sensory, read-aloud prose. Describe before naming. No GM secrets.

## GM Sidebar
Plain explanation of function, real-world comparison, pacing role, and how to use it.

## Show/Tell Rationale
- What is shown:
- What is told:
- Why this balance fits:

## Table Use
- Say:
- Let players ask:
- Reveal only if:
```

## NPC Personality

```markdown
## Claim
What trait, wound, desire, contradiction, or social role should the audience infer?

## Evidence
- Action:
- Dialogue:
- Object/detail:
- Habit:
- Contradiction:

## At the Table
- First impression:
- If pressured:
- If trusted:
- If ignored:
- One line they would say:
- One thing they will not say directly:
```

## Emotion Rewrite

```markdown
## Emotion Target
What should the audience infer?

## Avoid Saying
List direct emotion labels to avoid unless needed.

## Evidence Menu
- Body:
- Action:
- Thought:
- Dialogue:
- Environment:
- Object:
- Other character reaction:

## Draft
```

