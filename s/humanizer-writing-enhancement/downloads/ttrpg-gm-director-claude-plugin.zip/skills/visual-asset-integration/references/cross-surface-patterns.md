# Cross-Surface Patterns

## Websites And Landing Pages

- Prioritize first-screen comprehension and trust.
- Use hero media to clarify the offer, product, place, person, or experience.
- Keep decorative art out of proof positions.
- Verify mobile hero height and call-to-action visibility.

## Apps And Dashboards

- Treat screenshots and state art as interface evidence.
- Use familiar icons for common actions.
- Use generated or custom assets for empty states, onboarding, and product
  identity only when they improve clarity.
- Do not let decorative imagery reduce scanability.

## Games

- Separate gameplay screenshots, concept art, UI icons, sprites, background art,
  and marketing art.
- Gameplay proof should show actual or representative play state.
- Concept art can establish tone but should not replace gameplay evidence.

## Docs, Reports, And Decks

- Use visuals to explain, compare, summarize, or prove.
- Keep screenshots readable at presentation size.
- Caption why the visual matters.
- Do not shrink important claims below readable size to fit an image.

## Portfolios And Case Studies

- Treat the surface as a proof system.
- Put real artifacts near strong claims.
- Use generated visuals for mood only unless explicitly illustrative.
- Keep source labels and permission status in metadata or internal notes.

## Shareables And Public Artifacts

- Verify public-safety, source status, and destination path.
- Prefer self-contained assets or reliable relative paths.
- Run live smoke tests after publish.
- Avoid broad publishing commands from stale working trees.
