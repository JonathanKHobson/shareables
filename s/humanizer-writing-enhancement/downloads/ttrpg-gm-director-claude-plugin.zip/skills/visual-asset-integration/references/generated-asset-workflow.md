# Generated Asset Workflow

Use generated assets after placement intent is clear.

## Before Generation

Record:

- asset purpose
- target slot or anchor ID
- adjacent claim or UI job
- source status needed
- aspect ratio and crop behavior
- style, tone, palette, and avoid list
- whether people, identity, text, logos, or real-world evidence are involved

## Generation Rules

- Generate `environment`, `atmosphere`, `identity`, and `interface` assets when
  real sources are missing or a designed system is needed.
- Do not generate `evidence` for real events, people, user behavior, gameplay,
  product behavior, or outcomes.
- For people or real-session atmosphere, label generated outputs as
  illustrative if they are public.
- Save the final prompt, model/tool, source inputs, output path, and status in a
  manifest or asset note.
- After every Codex app generation, run the imagegen persistence recovery gate
  before treating the asset as usable. Chat previews are not source files.

## Persistence Recovery Gate

Codex can display a finished image in chat while no durable image file is saved.
The generation record may still say `status="generating"` even though the image
bytes are present in the thread rollout JSONL. After every generated image:

1. Run the recovery script from the project root.
2. Copy the newest recovered image into a stable project path.
3. Verify it is non-empty and has dimensions.
4. Use only that absolute path for edits, derivatives, placement, and QA.

Recovery script source:

```bash
/Volumes/KyleSSD/Documents/My Projects/imagegen-recovery/recover_codex_imagegen.py
```

Project-local command pattern:

```bash
python3 scripts/recover_codex_imagegen.py \
  --latest-only \
  --name-hint "<slug-or-asset-name>" \
  --copy-latest-to "/absolute/project/path/.codex-outputs/images/<lane>/<slug>_v01_<YYYYMMDD>_<HHMMSS>.png"
```

Verification:

```bash
test -s "/absolute/path/to/image.png"
/usr/bin/sips -g pixelWidth -g pixelHeight "/absolute/path/to/image.png"
```

If no recovered image appears, stop. Do not use guessed paths, screenshots of
the computer, copied chat previews, web images, SVG/vector placeholders, or
prompt-only fallbacks.

## Green-Screen Or Cutout Workflows

- Use cutouts for icons, portraits, props, badges, and UI assets when they need
  to sit on varied backgrounds.
- Generate one icon/cutout per image. Do not generate a sheet of multiple icons
  when the final assets need clean individual crops.
- Ask for a solid chroma-key green background (`#00ff00`), not transparency, for
  Codex app generations.
- Recover and verify the green-screen source first, then remove/key out the
  generated background before integration.
- Inspect edges at intended rendered size.
- Keep source and transparent derivatives separate.

## Rejection Rules

Reject or rework generated assets when they:

- look fake in a proof slot
- imply a real session, user, product, or outcome that did not happen
- introduce wrong world, product, or brand details
- contain unreadable or incorrect text
- clash with the surrounding visual system
- require captions to explain why they are present
