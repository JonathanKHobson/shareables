# Evidence And Source Status

Use source status to keep trust intact.

## Source Labels

| Label | Use When | Public UI Treatment |
| --- | --- | --- |
| `verified_source` | Real artifact, screenshot, photo, export, or document is directly available | Can support proof claims |
| `source_backed_derivative` | Cropped, edited, composited, or optimized from a real source | Can support proof claims if edits do not change meaning |
| `illustrative_generated` | AI-generated or staged visual used for mood or explanation | Do not present as proof |
| `draft_or_pending` | Asset or permission is incomplete | Keep out of public UI or label carefully |
| `unknown_source` | Source cannot be confirmed | Do not use as proof |

## Public Copy Rules

- Visitor-facing captions should explain value, not production status.
- Put source labels, prompts, approval notes, and temporary caveats in manifests
  or internal docs.
- When public labeling is needed, prefer concise wording such as
  "Illustrative concept image" or "Screenshot from the tool."

## Portfolio And Case-Study Rule

For public proof surfaces, the asset must answer:

- What work happened?
- What artifact, behavior, or outcome is visible?
- Why should a reviewer or buyer trust it?
- What remains unverified?

If those answers are weak, do not use the asset as evidence.
