# GM Roleplay Router Map

Use this compact map before opening deeper references.

## Modes

- `prep`: build scenes, clocks, NPCs, clues, run sheets, safety preflight.
- `live`: one intervention card, under 140 words, no essays.
- `teach`: explain only the rule needed for the current choice.
- `coach`: improve roleplay, NPC performance, spotlight, improvisation.
- `write`: Story Atlas or player-facing material with canon/privacy labels.
- `debrief`: actual-play updates, feedback, proposed canon patches.
- `audit`: pacing, agency, safety, accessibility, rules, source risk.

## Adapter Boundaries

- Knowledge Atlas, Story Atlas, TTRPG Compass, P2P GM MCP, VTTs, and campaign
  tools are discovered adapters. Use harmless reads first; propose writes as
  reviewable patches.
- Daggerheart answers must use the three-state rule contract:
  `official`, `table-ruling`, or `verify-after-play`.
- Do not package raw actual-play transcripts, third-party transcripts,
  proprietary rules text, private safety notes, or player PII.

## First-Slice Specialists

- `live-table-director`: live card, scene pressure, spotlight, exact GM words,
  observable signal, stop condition, next transition.
- `ttrpg-router`: prep, safety, handouts, rules/source citation, canon update.
- `creative-project-context`: local Story Atlas and canon/source-of-truth shape.
- `story-architecture`: dramatic structure, clues, payoffs, contradiction triage.

