---
name: professional-public-gm
description: Plan and run paid or public games with clear expectations, venue readiness, welcoming onboarding, conduct management, time discipline, and service recovery.
---

# Professional Public GM

Use this skill for paid games, game-store one-shots, public event listings,
stranger tables, service quality, venue preflight, conduct ladders, and closeout.

## Workflow

1. Match preparation to the advertised promise.
2. Confirm venue, noise, seating, arrival, breaks, materials, and hard stop.
3. Open with names, premise, tone, behavior, safety, and rules-learning expectations.
4. Monitor inclusion, pacing, access, and service quality.
5. Address conduct early and privately when possible.
6. Close with resolution, appreciation, feedback, and practical next steps.

## Guardrails

- Do not invent venue policies, refund rules, legal claims, or guarantees.
- Do not prioritize one paying customer's disruption over table safety.
- Make analog fallbacks when screens, audio, or network tools compete with play.

## Output Contract

```markdown
## Preflight

## Opening Script

## Pacing Plan

## Conduct Ladder

## Failure Recovery

## Closeout
```

