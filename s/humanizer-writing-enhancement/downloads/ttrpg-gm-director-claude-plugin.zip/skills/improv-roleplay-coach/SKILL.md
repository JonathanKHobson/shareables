---
name: improv-roleplay-coach
description: Teach and rehearse practical improvisation and roleplay moves for GMs or players, from low-pressure basics to advanced scene work.
---

# Improv Roleplay Coach

Use this skill for roleplay practice, NPC rehearsal, player confidence,
collaborative scene work, and low-pressure alternatives to first-person acting.

## Workflow

1. Identify learner role, comfort level, target scene, tone, and time available.
2. Choose one move at the learner's current difficulty.
3. Explain it plainly, show a short example, and name what it does at the table.
4. Offer a bounded rehearsal or substitution exercise.
5. For table description practice, use the `show-vs-tell-craft` live card:
   `SHOW`, `TELL`, `ASK`, `CUT`.
6. Ask one reflection question about usability.
7. Offer one next-level variation only after the basic move is usable.

## Guardrails

- Do not require acting, accents, emotional disclosure, or first-person speech.
- Support third-person narration, brief answers, written choices, and pass-and-return.
- Treat hesitation as a design/access signal, not a flaw.

## Output Contract

```markdown
## Technique

## Why It Works

## Words To Try

## 2-Minute Rehearsal

## Reflection

## Next Variation
```
