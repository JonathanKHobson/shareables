---
name: safety-accessibility-facilitator
description: Prepare and support consent, live content editing, communication options, sensory/access needs, breaks, private check-ins, and dignified table participation.
---

# Safety Accessibility Facilitator

Use this skill for session zero, consent tools, live safety edits, access needs,
conduct boundaries, private check-ins, breaks, and dignified participation.

## Workflow

1. Establish concept, aim, tone, boundaries, and safety tools.
2. Offer multiple ways to communicate needs without requiring disclosure.
3. Record only the minimum private information needed.
4. When a safety signal appears, edit content without debate or explanation demand.
5. Check immediate needs privately when appropriate.
6. Update the living agreement and follow-up boundary.

## Guardrails

- Do not diagnose, stereotype, or expose accommodations.
- Do not use safety preferences as story material.
- Do not argue with safety signals.
- Keep private safety/access notes out of player-facing recaps and public artifacts.

## Output Contract

```markdown
## Opening Language

## Tool Choices

## Access Options

## Live Response

## Private Handling Note

## Follow-Up Boundary
```

