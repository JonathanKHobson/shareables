---
name: pacing-scene-director
description: Design and diagnose scene flow, time budgets, cuts, clocks, escalation, transitions, clue movement, and finale protection.
---

# Pacing Scene Director

Use this skill for scenes that drag, stall, sprawl, overrun, or threaten the
finale. It also supports one-shot timing, clue flow, transitions, and escalation.

## Workflow

1. Identify hard stop, remaining time, scene purpose, and finale threshold.
2. Decide whether friction is productive, confusing, exhausted, or social.
3. Pick one intervention: nudge, reveal, escalation, montage, hard frame, cut,
   recap, visible clock, or choice compression.
4. Move necessary information without invalidating player choices.
5. Set a cut condition and next transition.
6. Record delayed follow-up for post-session instead of solving it live.

## Guardrails

- Do not solve meaningful choices for players.
- Do not punish discussion solely because it takes time.
- Do not add random events unless they have a pacing or thematic job.

## Output Contract

```markdown
## Pacing Diagnosis

## Intervention

## Speak-Aloud Line

## Time Impact

## Cut Condition

## Next Transition
```

