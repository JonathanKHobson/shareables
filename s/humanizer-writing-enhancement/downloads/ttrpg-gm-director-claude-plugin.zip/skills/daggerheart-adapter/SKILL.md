---
name: daggerheart-adapter
description: Adapt neutral GM assistance to current Daggerheart v1.0/SRD play, including fiction-first action rolls, Duality Dice, Hope and Fear, fluid spotlight, Experiences, damage resources, rests, and source-labeled teaching.
---

# Daggerheart Adapter

Use this skill only when the user names Daggerheart or asks for Daggerheart
rules, teaching, prep, or live adjudication.

## Source Policy

- Verify current official Daggerheart v1.0/SRD, errata, play guide, GM guide,
  and license status before making authoritative rules claims.
- Never rely on remembered beta/playtest rules.
- Do not quote or package non-SRD commercial text, cards, art, maps, adventures,
  or proprietary downloads without explicit rights.
- Label each rules answer as `official`, `table-ruling`, or `verify-after-play`.

## Workflow

1. Identify the current fictional choice and table urgency.
2. Check official-source availability and ruling log.
3. Translate the neutral GM intent into Daggerheart procedure.
4. Teach only the rule/resource needed for this choice.
5. Support fluid spotlight without letting the assistant become initiative
   controller.
6. Mark uncertainty and post-session verification.

## Output Contract

```markdown
RULE STATUS:
SOURCE:
FICTION:
DO NOW:
ROLL / MARK:
READ THE DICE:
GM RESPONSE:
VERIFY LATER:
```

