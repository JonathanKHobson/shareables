# Game Design Frameworks

Use this file to choose the smallest useful design lens for the current problem. Do not load the whole file unless the task genuinely needs framework selection or a reminder of design vocabulary.

## MDA

- Best for: tracing why a mechanic produces the wrong feeling or why a design is mechanically sound but emotionally flat
- Ask:
  - What mechanics are present?
  - What dynamics emerge when players optimize them?
  - What aesthetic or emotional outcome does the player actually feel?
- Use when:
  - the user says the game is not fun, tense, fair, satisfying, or thematic
  - a system works on paper but feels dead in play

## Formal Elements

- Best for: defining what the game actually is when the concept is fuzzy
- Check:
  - players
  - objectives
  - procedures
  - rules
  - resources
  - boundaries
  - conflict and outcomes
- Use when:
  - a game pitch is still a vibe cloud
  - a ruleset is incomplete or contradictory

## Meaningful Play

- Best for: checking whether player actions are legible and consequential
- Ask:
  - Can players perceive the result of their action?
  - Does that result matter to the wider system?
- Use when:
  - choices feel decorative
  - feedback is muddy
  - outcomes feel arbitrary

## Core Loop

- Best for: understanding the repeatable cycle that makes the game sticky or dull
- Map:
  - trigger
  - action
  - reward
  - new decision or renewed tension
- Use when:
  - the game drags
  - the prototype has cool moments but no heartbeat
  - progression exists but the minute-to-minute loop is weak

## Feedback Loops

- Best for: diagnosing snowballing, comeback mechanics, escalation, and stability
- Distinguish:
  - positive feedback: advantage creates more advantage
  - negative feedback: the system pushes back toward parity
- Use when:
  - a leader runs away
  - losing players never recover
  - catch-up systems feel unfair or too strong

## Economy Thinking

- Best for: balancing currencies, actions, upgrades, time pressure, and progression pacing
- Track:
  - sources
  - sinks
  - scarcity
  - conversion rates
  - tempo
  - opportunity cost
- Use when:
  - progression feels grindy
  - upgrades trivialize choices
  - one resource dominates the system

## Decision Vocabulary

- Best for: evaluating whether choices are interesting and counterable
- Watch for:
  - dominant strategy
  - false choice
  - risk/reward mismatch
  - missing counterplay
  - degenerate play
  - runaway leader
- Use when:
  - players converge on one obvious line
  - balance complaints keep repeating

## Self-Determination Theory

- Best for: motivation, retention, and player satisfaction
- Check:
  - autonomy: do players feel agency?
  - competence: do players feel effective and improving?
  - relatedness: do players feel socially connected or meaningfully compared?
- Use when:
  - the game feels hollow despite functioning systems
  - onboarding or progression kills motivation
  - social features are being designed

## Flow

- Best for: tuning difficulty, mastery ramps, and pacing
- Ask:
  - Is challenge below skill and therefore boring?
  - Is challenge above skill and therefore frustrating?
  - Is the ramp teaching mastery or punishing ignorance?
- Use when:
  - difficulty spikes feel unfair
  - content is easy but tedious
  - players bounce during onboarding

## Playcentric Iteration

- Best for: deciding what to prototype, test, and revise next
- Sequence:
  - define the hypothesis
  - prototype the smallest version
  - observe actual behavior
  - revise the system
  - retest
- Use when:
  - the team is arguing from theory alone
  - multiple possible fixes exist
  - you need the next playtest to answer a specific question
