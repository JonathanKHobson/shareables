# Artifact Templates

Use these templates to keep outputs concrete and consistent. Trim sections that do not matter for the request.

## Concept Brief

```markdown
# Concept Brief

## Fantasy
[What it should feel like to play]

## Player and Format
[Who it is for, player count, platform, session length, genre or comparable]

## Core Verbs
- [verb]
- [verb]
- [verb]

## Core Loop
[One short loop sentence or 3-5 step sequence]

## Primary Tension
[What creates pressure, scarcity, danger, or uncertainty]

## Key Decisions
- [decision and tradeoff]
- [decision and tradeoff]
- [decision and tradeoff]

## Risks
- [design risk]
- [production risk]

## Next Prototype
[Smallest testable version]
```

## Core Loop Sheet

```markdown
# Core Loop Sheet

## Loop
1. [trigger]
2. [player action]
3. [system response]
4. [reward or consequence]
5. [new decision or renewed pressure]

## Player Verbs
- [verb]
- [verb]

## Resources in Motion
- [resource]: [source -> sink]

## Why the Loop Is Satisfying
- [reason]

## Likely Failure Modes
- [failure mode]
- [failure mode]

## Validation
[What to observe in the next playtest]
```

## Mechanics Spec

```markdown
# Mechanics Spec

## Goal
[What this mechanic is meant to add]

## Inputs and Verbs
- [input or action]

## Rules
- [rule]
- [rule]
- [rule]

## Resources and Constraints
- [resource, cooldown, cost, position, timing, risk]

## Player Decision
[Why and when the player chooses this]

## Counterplay or Failure Case
[How opponents, the environment, or the system answer it]

## Tuning Knobs
- [number or variable]
- [number or variable]

## Test Case
[Simple scenario to validate the mechanic]
```

## Balance Diagnosis

```markdown
# Balance Diagnosis

## Problem Statement
[What feels unfair, solved, weak, or degenerate]

## Likely Cause
[Dominant strategy, missing counterplay, snowballing, poor readability, low opportunity cost, etc.]

## Evidence
- [observed behavior]
- [observed behavior]

## System Incentive
[What the game is rewarding right now]

## Recommended Change
[Smallest change to test]

## Tradeoff
[What this fix may worsen]

## Validation Plan
[How to test whether the fix worked]
```

## Progression or Economy Outline

```markdown
# Progression/Economy Outline

## Player Goal
[Why players engage with this system]

## Main Resources
- [resource]
- [resource]

## Sources
- [source]

## Sinks
- [sink]

## Unlock Rhythm
[How capability or stakes expand over time]

## Tension Points
- [scarcity or choice pressure]

## Risks
- [grind, inflation, dead currency, solved path, retention pressure]

## Metrics or Signals
- [what to observe in testing or telemetry]
```

## Playtest Plan

```markdown
# Playtest Plan

## Question
[What this test needs to learn]

## Build Under Test
[Prototype scope]

## Target Players
[Who should play]

## Scenario
[What they will do]

## What to Observe
- [behavior]
- [behavior]
- [behavior]

## Questions to Ask
- [question]
- [question]

## Success Signal
[What result would support the hypothesis]

## Failure Signal
[What result would falsify it]

## Next Iteration
[What change to make depending on outcome]
```

## Post-Playtest Findings Summary

```markdown
# Post-Playtest Findings

## Test Goal
[Original question]

## Observed Behavior
- [behavior]
- [behavior]

## What Players Thought Was Happening
- [belief or quote]

## What the System Actually Rewarded
[Incentive summary]

## Findings
- [finding]
- [finding]

## Recommended Changes
- [change]
- [change]

## Next Test
[What to validate next]
```
