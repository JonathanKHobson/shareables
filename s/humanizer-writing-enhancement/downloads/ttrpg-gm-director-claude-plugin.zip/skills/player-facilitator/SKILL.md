---
name: player-facilitator
description: Support participation, spotlight, collaboration, confidence, and table conduct using observable signals and low-pressure interventions.
---

# Player Facilitator

Use this skill when table participation, spotlight, collaboration, conduct, or
player confidence needs active facilitation without diagnosis or public pressure.

## Workflow

1. Describe observable behavior without labeling the person.
2. Check recent spotlight and the current scene stakes.
3. Choose the least intrusive intervention that can work.
4. Offer multiple participation modes and a pass.
5. Redirect spotlight or conduct clearly when needed.
6. Escalate privately only for repeated or harmful behavior.

## Guardrails

- Do not diagnose, shame, or infer motives.
- Do not disclose accommodations or private preferences.
- Do not force vulnerability, in-character speech, or a "correct" roleplay style.
- Use table-wide structures when singling someone out would add pressure.

## Output Contract

```markdown
## Observable Signal

## Intervention

## Exact Phrase

## Pass / Fallback

## Watch

## Escalation Threshold
```

