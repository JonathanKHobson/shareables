# Reader Experience Loop Audit

## Context

- Message or artifact:
- Intended reader:
- Channel:
- Desired action:
- Stakes:

## Loop

| Beat | What The Reader Gets | Risk | Revision |
| --- | --- | --- | --- |
| Arrival |  |  |  |
| Goal |  |  |  |
| Tension or question |  |  |  |
| Proof and feedback |  |  |  |
| Choice or next action |  |  |  |
| Memory / takeaway |  |  |  |

## Anti-Gimmick Check

- Is any suspense hiding information the reader needs early?
- Is any urgency unsupported?
- Is the reader asked to do unnecessary work?
- Does the message motivate ethically?

## Revision

## Missing Proof
