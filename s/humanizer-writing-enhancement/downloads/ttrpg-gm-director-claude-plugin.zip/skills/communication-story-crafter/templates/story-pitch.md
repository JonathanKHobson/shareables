# Story Or Pitch Template

```markdown
## Communication Strategy
- Intent:
- Audience:
- Frame:
- Hook:
- Main claim:
- Proof:
- Stakes:
- Ask or payoff:

## Draft

## Story Spine
- Someone wanted:
- Obstacle:
- What it reveals:
- What should happen next:

## Rhetorical Balance
- Ethos:
- Logos:
- Pathos:
- Kairos:

## Missing Proof Or Cautions
```
