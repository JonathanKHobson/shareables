# Proposal Message Template

```markdown
## Proposal Message Strategy
- Buyer problem:
- Decision to support:
- Audience/users:
- Constraints:
- Recommended offer:
- Proof:
- Assumptions:
- Next step:

## Understanding

## Recommended Approach

## Deliverables
- 
- 
- 

## Timeline And Scope

## Boundaries

## Relevant Proof

## Questions Or Assumptions
- 
- 

## Next Step
```
