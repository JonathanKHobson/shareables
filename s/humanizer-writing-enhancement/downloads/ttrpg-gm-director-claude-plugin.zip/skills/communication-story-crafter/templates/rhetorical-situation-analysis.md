# Rhetorical Situation Analysis Template

```markdown
## Rhetorical Situation
- Mode: create / critique / coach / practice / simulate / teach
- Speaker:
- Audience:
- Relationship:
- Channel:
- Purpose:
- Stakes:
- Constraints:
- Power dynamics:
- Emotional context:
- Action needed:
- Likely misread:

## Recommended Strategy
- Frame:
- Structure:
- Tone:
- Evidence:
- Ask:

## Draft Or Revision

## Reader Simulation
- What the reader understands:
- What the reader may question:
- What could be misread:
- Trust builder:

## Self-Check
- Is the ask clear?
- Is the emotional temperature appropriate?
- Is the proof sufficient?
- Is the sequence easy to follow?
- What should be verified before sending?
```
