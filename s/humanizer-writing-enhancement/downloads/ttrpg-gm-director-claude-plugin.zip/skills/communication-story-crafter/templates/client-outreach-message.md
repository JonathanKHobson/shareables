# Client Outreach Message Template

```markdown
## Outreach Strategy
- Recipient:
- Relationship/context:
- Buyer problem or decision:
- Why now:
- Relevant proof:
- Ask:
- Opt-out:

## Draft
Hi [Name],

[Specific context.]

[Connection to a problem, decision, or uncertainty.]

[Relevant service or useful next step.]

[Respectful ask with opt-out.]

## Variants
1. Warmer:
2. More direct:
3. Shorter:

## Integrity Check
- Supplied proof only:
- No pressure tactic:
- No bulk automation:
- Clear next action:
```
