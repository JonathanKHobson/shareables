# Hook Set Template

```markdown
## Best Hook

## Alternative Hooks
1.
2.
3.
4.
5.

## Pattern Notes
- Hook type:
- Audience promise:
- Proof type needed:
- Likely reader:
- Ethical risk:

## Recommendation
Use option [x] because [reason].
```
