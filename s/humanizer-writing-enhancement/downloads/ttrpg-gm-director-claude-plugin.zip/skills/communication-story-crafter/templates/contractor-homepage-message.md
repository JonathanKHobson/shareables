# Contractor Homepage Message Template

```markdown
## Homepage Strategy
- Audience:
- Buyer problem:
- Core outcome:
- Primary service lane:
- Proof available:
- Proof gaps:
- Primary CTA:
- Secondary CTA:

## Hero
Headline:

Subheadline:

Primary CTA:

Secondary CTA:

## Trust Strip
- [Supplied proof point]
- [Supplied proof point]
- [Supplied proof point]

## Problem Framing

## Services Preview
### [Service Name]
- For:
- Solves:
- Includes:
- Next step:

## Process
1. Scope:
2. Study:
3. Synthesize:
4. Recommend:

## Proof Section
- Case or artifact:
- What it proves:
- Missing proof:

## Point Of View

## Final CTA
```
