# Stakeholder Readout Template

```markdown
## TL;DR

## Why This Matters Now

## Finding Or Recommendation

## Evidence

## Impact

## Options

## Recommendation

## Decision Or Support Needed

## Confidence And Caveats
```
