# Sensitive Message Template

```markdown
## What You Seem To Mean

## What Could Land Poorly

## Keep

## Remove Or Soften

## Calm Professional Version

## Direct Version

## Warm Version

## Recommendation
```
