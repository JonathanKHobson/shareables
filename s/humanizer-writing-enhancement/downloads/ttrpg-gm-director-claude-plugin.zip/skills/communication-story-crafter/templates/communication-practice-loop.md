# Communication Practice Loop Template

```markdown
## Practice Goal
- Subskill:
- Scenario:
- Audience:
- Constraint:
- Success criteria:

## Worked Example

## Why It Works
| Element | Function |
| --- | --- |
|  |  |

## Guided Draft
Fill the missing sections:

1. Context:
2. Main point:
3. Proof:
4. Ask:
5. Close:

## Independent Attempt Prompt
[Write a new version under the stated constraints.]

## Feedback Rubric
- Audience fit:
- Clarity:
- Tone:
- Evidence:
- Ask/action:
- Risk management:

## Transfer
- Use this when:
- Adapt for:
- Do not use when:
- Next real-world test:
```
