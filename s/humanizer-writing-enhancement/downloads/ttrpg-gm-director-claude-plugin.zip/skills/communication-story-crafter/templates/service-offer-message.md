# Service Offer Message Template

```markdown
## Offer Strategy
- Buyer situation:
- Decision or risk:
- Outcome:
- Method:
- Deliverables:
- Typical timeline:
- Boundaries:
- Proof:
- Next step:

## Offer Card
### [Offer Name]
**For:**  
**Outcome:**  
**Includes:**  
**Typical timeline:**  
**Not included:**  
**Good fit when:**  
**Next step:**  

## Sales Page Section
### The Problem

### What You Get

### How It Works

### Proof Or Relevant Experience

### Scope Notes

### CTA

## Missing Proof Or Decisions
- [MISSING INFO: ...]
```
