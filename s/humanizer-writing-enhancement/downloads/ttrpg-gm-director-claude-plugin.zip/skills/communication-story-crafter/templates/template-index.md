# Template Index

Use these templates as starting points, then adapt to the user's actual facts,
reader, channel, and evidence.

| Need | Template |
| --- | --- |
| Story or pitch strategy | `story-pitch.md` |
| Hook options | `hook-set.md` |
| Stakeholder update or readout | `stakeholder-readout.md` |
| Job-search message | `job-search-message.md` |
| Sensitive or repair message | `sensitive-message.md` |
| Communication audit | `communication-audit.md` |
| Reader journey, agency, feedback, and memory audit | `reader-experience-loop-audit.md` |
| Rhetorical situation, reader risk, and action analysis | `rhetorical-situation-analysis.md` |
| Practice, coaching, and transfer loop | `communication-practice-loop.md` |
| Contractor homepage or service-business landing message | `contractor-homepage-message.md` |
| Service offer, package, or sales-page section | `service-offer-message.md` |
| Respectful client outreach | `client-outreach-message.md` |
| Proposal, inquiry response, or scoped next-step message | `proposal-message.md` |
