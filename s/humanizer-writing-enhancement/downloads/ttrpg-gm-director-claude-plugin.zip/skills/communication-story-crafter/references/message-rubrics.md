# Message Rubrics

Use these rubrics to audit a draft before sharing it.

## Communication Health Snapshot

```markdown
## Communication Health Snapshot
- Intent:
- Audience:
- Channel:
- Overall read:
- Strongest part:
- Biggest risk:
- First fix:
```

## Core Message Rubric

Score 1-5:

- Intent clarity
- Audience fit
- Hook relevance
- Structure
- Evidence support
- Voice fidelity
- Brevity
- Tone fit
- Ask clarity
- Ethical persuasion

## Rhetorical Balance

```markdown
## Ethos / Logos / Pathos / Kairos
- Ethos:
- Logos:
- Pathos:
- Kairos:
- Missing appeal:
- Overused appeal:
- Revision:
```

## Tone Risk Audit

```markdown
## Tone Risk
- Defensive:
- Overexplaining:
- Blame:
- Pressure:
- Desperation:
- Too cold:
- Too casual:
- Preserves dignity:
- Moves relationship forward:
```

## Reader Reaction Simulation

Use this as a cautious lens, not certainty:

```markdown
## Possible Reader Reaction
- Recruiter:
- Hiring manager:
- Technical stakeholder:
- Skeptical reader:
- Friend or weak tie:
- What to change:
```

## Send / Share Readiness

A message is ready for review when:

- The point appears early.
- The reader can tell why it matters.
- The proof is real or marked missing.
- The ask is clear and proportionate.
- The tone fits the stakes.
- The draft does not sound generically AI-polished.
