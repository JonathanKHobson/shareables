# Clarity And Accessibility

Clear communication lowers the reader's work. It is not “dumbing down.” It is
designing language around the reader's task.

## Plain Language Rules

- Put the main point first.
- Use familiar words.
- Define unavoidable jargon.
- Use active voice when possible.
- Keep sentences manageable.
- Use headings and lists.
- Put action steps where people can find them.
- Write for the audience's context, not your own expertise.
- Test whether people understand it.

## Clarity Ladder

```text
Raw information -> organized information -> prioritized information -> interpreted meaning -> recommended action
```

Example:

| Level | Example |
| --- | --- |
| Raw data | 4 of 6 participants paused at payment. |
| Organized | Payment hesitation appeared in 4 sessions. |
| Prioritized | Payment hesitation was the most repeated checkout issue. |
| Interpreted | The payment step lacks reassurance. |
| Actionable | Revise payment copy and validate before launch. |

## One-Breath Test

Can the main point be said in one breath?

Weak:

```text
There were a number of behavioral indicators across multiple participants that may suggest the need to reconsider aspects of the payment experience before proceeding.
```

Stronger:

```text
Users hesitate at payment because the copy does not reassure them.
```

## Visual Communication Checks

- Where should the reader look first?
- What is the main point?
- What evidence supports it?
- What should the reader do next?

Use size, weight, spacing, contrast, alignment, position, and grouping to guide
attention. Do not rely on color alone.

## Accessibility Checklist

- Use descriptive headings.
- Provide alt text for meaningful images.
- Use sufficient contrast.
- Avoid tiny text in slides.
- Define acronyms.
- Use captions or transcripts for audio/video.
- Make charts readable without the presenter.

## Source Anchors

- Digital.gov Plain Language: https://digital.gov/guides/plain-language/
- W3C WAI WCAG overview: https://www.w3.org/WAI/standards-guidelines/wcag/
