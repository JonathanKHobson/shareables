# Stakeholder Communication

Stakeholder communication should move people from information to a decision,
alignment, or next action.

## Stakeholder Needs

| Stakeholder | Cares About | Communication Need |
| --- | --- | --- |
| Executive | Risk, ROI, strategy, timing | Bottom line, decision, tradeoff |
| Product manager | Priorities, roadmap, scope | Impact, sequencing, options |
| Designer | User needs, interaction quality | Behavior, examples, constraints |
| Engineer | Feasibility, requirements, edge cases | Specifics, logic, dependencies |
| Researcher | Method, validity, interpretation | Evidence, caveats, rigor |
| Marketing | Message, positioning, adoption | Story, audience, differentiation |
| Support | Pain points, operational impact | Examples, frequency, scripts |
| Legal or compliance | Risk, accuracy, obligations | Documentation, constraints, audit trail |
| Sales | Buyer needs, objections, urgency | Narrative, proof, competitive angle |

## Stakeholder Analysis Questions

- What decision can this person influence?
- What do they already believe?
- What are they worried about?
- What would make them trust the message?
- What level of detail do they need?
- What constraints are they under?
- What would make this feel like a win?
- What could make them resist, even if the message is true?

## Stakeholder Formula

```text
Context: Here is why this matters now.
Finding: Here is the clearest insight.
Evidence: Here is why we believe it.
Impact: Here is what it affects.
Options: Here are possible paths.
Recommendation: Here is what I suggest.
Ask: Here is the decision or support needed.
```

## Handling Resistance

| Signal | Possible Meaning | Response |
| --- | --- | --- |
| “The sample is too small.” | Evidence concern | Clarify confidence and triangulation. |
| “We do not have time.” | Timing or scope concern | Offer the smallest useful action. |
| “That is not a priority.” | Strategic mismatch | Link to business or user goal. |
| “Users always say that.” | Trust issue | Show behavior, not just quotes. |
| “We already decided.” | Process issue | Ask what evidence would change the decision. |

## Smallest Useful Ask

Ask for the next useful decision, not the largest possible commitment.

Weak:

```text
We need to redesign checkout.
```

Stronger:

```text
We need approval to test revised payment copy with five users before launch.
```
