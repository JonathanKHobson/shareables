# Client Outreach And Proposals

Use this reference for human-controlled client outreach, inquiry responses,
proposal language, and follow-up copy. Do not automate sending, scraping, bulk
messaging, or platform actions.

## Pipeline Frame

```text
Awareness -> Trust -> Inquiry -> Discovery -> Proposal -> Contract -> Project -> Referral
```

Write the current message for the current stage. Do not push for a proposal
when the reader only needs orientation, and do not write vague networking copy
when the reader has already described a problem.

## Warm Outreach Pattern

```markdown
Hi [Name],

I noticed [specific context].

It made me think about [buyer problem or decision], especially because
[reason this might matter].

I help with [specific service or outcome]. If useful, I can [small next step].

No pressure if this is not timely. Would [specific ask] be useful?
```

Keep the ask respectful, time-bounded, and easy to decline.

## Inquiry Response Pattern

```markdown
Thanks for the context. It sounds like the core decision is [decision/problem].

The first thing I would clarify is [scope question]. From there, the lightest
useful path may be [audit/sprint/review/workshop], depending on [constraint].

A few questions:
- [Question 1]
- [Question 2]
- [Question 3]

Once I have those answers, I can suggest a focused next step.
```

## Proposal Message Pattern

```markdown
## Understanding
[Restate the buyer's problem, decision, audience, and risk.]

## Recommended Approach
[Describe the method in plain language.]

## Deliverables
- [Deliverable]
- [Deliverable]
- [Deliverable]

## Timeline And Scope
[Use supplied or approved timing. Name boundaries.]

## Relevant Proof
[Only supplied evidence.]

## Questions Or Assumptions
- [Question or assumption]

## Next Step
[Concrete human-controlled action.]
```

## Review Checks

- Does the message start from the buyer's problem rather than the writer's
  biography?
- Is the next action specific and low-friction?
- Are proof points supplied and defensible?
- Are boundaries and assumptions visible?
- Would the message still feel respectful if the recipient says no?
