# Contractor Brand Messaging

Use this reference when the user is turning a portfolio, personal brand, or
consulting service into buyer-facing copy. Keep the guidance generic and work
only from supplied facts.

## Core Reframe

A portfolio says, "Here is what I have done." Contractor brand messaging says,
"Here is the problem I solve, how I solve it, why you can trust me, and what to
do next."

Write for buyer uncertainty rather than self-description:

- What is unclear, risky, slow, confusing, or expensive for the buyer?
- What decision do they need to make?
- What offer reduces that uncertainty?
- What proof supports the claim?
- What is the lowest-friction next step?

## Positioning Formula

```text
Audience + problem + method + outcome + point of view
```

Use this before writing homepage, services, LinkedIn, marketplace, or proposal
copy. If any slot is missing, mark it as `[MISSING INFO: ...]`.

## Contractor Copy Formula

```text
Problem -> Stakes -> Offer -> Proof -> Process -> CTA
```

- **Problem:** name the buyer's situation in their words.
- **Stakes:** explain what remains risky if nothing changes.
- **Offer:** say what help is available.
- **Proof:** use supplied artifacts, results, examples, credentials, or method
  evidence.
- **Process:** show what happens after contact.
- **CTA:** ask for the smallest useful next action.

## Homepage Message Pattern

1. Hero: service, audience, outcome.
2. Trust strip: specific supplied proof, not decorative badges.
3. Problem framing: what buyers are struggling to understand or decide.
4. Services: 3-5 named, buyable offers.
5. Process: how working together reduces uncertainty.
6. Proof: case cards, artifacts, metrics, testimonials, or sample deliverables.
7. Point of view: what makes the approach memorable.
8. CTA: inquiry, fit call, service request, or next-step question.

Avoid "Welcome to my portfolio," broad passion statements, tool lists without
outcomes, clever taglines without explanation, and vague "learn more" CTAs.

## Service Offer Formula

```text
Offer = buyer situation + outcome + method + deliverable + timeline + boundary
```

Good offer copy names what is included, what is not included, what changes
scope, and what next step follows the offer. Use "typical" timelines only when
the user supplies or approves them.

## Proof And Trust

Use a proof hierarchy:

1. Verified client or business outcome.
2. Specific metric or decision influenced.
3. Artifact, sample deliverable, or before/after example.
4. Method proof, process evidence, or credential.
5. Tool list or self-description.

Do not invent testimonials, logos, client names, revenue, timelines, metrics,
or results. When proof is weak, write a proof gap and suggest what evidence to
collect next.

## CTA Rules

- Match the CTA to buyer readiness.
- Prefer concrete actions: "Start a project inquiry," "Request an audit,"
  "Scope a research sprint," or "Send the project context."
- Avoid creating pressure, false urgency, or automated outreach.
- Tell the reader what happens next when possible.
