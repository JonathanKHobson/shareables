# Game Design Transfer For Communication

Use these lenses when a message, pitch, explainer, presentation, or story needs
clearer pacing, agency, feedback, stakes, or memorability. The goal is not to
turn the message into a game. The goal is to borrow the parts of game design
that help people orient, choose, understand consequences, and remember what
matters.

## Use When

- A reader may arrive confused, skeptical, rushed, or unsure what to do.
- A message has too much setup before the payoff.
- A story has events but no visible stakes, decision, consequence, or change.
- An explainer needs better reveal order, feedback, and transfer.
- A pitch or proposal needs a safer, clearer next action.

## Reader Experience Loop

Map the communication like a small experience:

```markdown
## Reader Experience Loop
- Arrival: What does the reader understand in the first few seconds?
- Goal: What are they trying to decide, learn, feel, or do?
- Tension: What question, risk, curiosity, or conflict keeps attention?
- Agency: What choice, interpretation, or next step is open to them?
- Feedback: What proof, example, consequence, or response confirms progress?
- Memory: What phrase, image, contrast, or decision should remain afterward?
```

## Useful Game-Design Lenses

| Lens | Communication Use |
| --- | --- |
| Player fantasy | Reader promise: what the reader is invited to imagine becoming, solving, or understanding. |
| Primary verb | The main action the reader should take: decide, reply, approve, inspect, try, share, or remember. |
| Core loop | The repeated pattern of claim, proof, implication, and next step. |
| Meaningful choice | Options are clear, tradeoffs are real, and consequences are visible. |
| Feedback | The message shows why a claim matters and how the reader can tell it is working. |
| Reveal pacing | Information arrives in an order that builds understanding instead of hiding basics. |
| Emotional pacing | Tension, relief, urgency, and confidence are proportionate to the stakes. |

## Choice And Consequence

Use choice/consequence framing when the reader needs to act:

- Name the choice.
- Explain why it matters now.
- Show what changes if they say yes, no, or wait.
- Provide a low-risk next step.
- Do not pressure with fake scarcity, shame, or manipulative urgency.

## Anti-Gamification Guardrails

Avoid:

- Points, badges, streaks, or progress bars with no real meaning.
- FOMO, scarcity, or urgency that the facts do not support.
- Puzzle-like writing that hides basic information.
- Interaction that makes a serious task feel trivial.
- "Fun" flourishes that delay the reader's actual goal.

Prefer:

- Clear goals.
- Immediate proof or examples.
- Optional depth.
- Ethical motivation.
- Feedback that teaches.
- A direct next action.
