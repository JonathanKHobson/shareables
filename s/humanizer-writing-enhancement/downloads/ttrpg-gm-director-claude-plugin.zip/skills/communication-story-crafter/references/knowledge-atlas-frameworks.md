# Knowledge Atlas Frameworks For Communication

Use these frameworks as routing tools. Pick the smallest useful frame instead
of stacking several.

## 4Ps: Promise, Picture, Proof, Push

Best for homepage sections, service pages, ads, short emails, and CTAs.

- **Promise:** the reader-facing outcome.
- **Picture:** a concrete scene of what changes.
- **Proof:** supplied evidence that makes the promise believable.
- **Push:** one low-friction next action.

Use this when copy is vague, proof is far from the claim, or the CTA is weak.

## AIDA: Attention, Interest, Desire, Action

Best for short persuasive copy, public posts, landing sections, and outreach.

- Attention should be honest, not clickbait.
- Interest should connect to the reader's situation.
- Desire should be grounded in a real reader win.
- Action should be the smallest useful next step.

## FAB: Feature, Advantage, Benefit

Best for turning capabilities into buyer-facing value.

```text
Feature: what the service includes
Advantage: why that helps
Benefit: what changes for the reader or team
```

Use this to turn tool lists, methods, or credentials into useful copy.

## SCQA: Situation, Complication, Question, Answer

Best for executive summaries, stakeholder updates, proposal openings, and
thought-leadership posts.

- Situation: shared context.
- Complication: what changed or remains unresolved.
- Question: the decision or tension.
- Answer: recommended path.

## Personal Value Proposition Canvas

Best for positioning and brand clarity.

Map:

- audience jobs, pains, and gains
- writer strengths, pain relievers, and gain creators
- proof points
- channels and next actions

Use this before writing brand statements, bios, and service pages.

## Public Narrative

Best when the user needs a values-based message with a clear ask.

Use:

- story of self
- story of us
- story of now
- ladder of asks
- inclusion and consent checks

## Evidence Confidence Grid

Best for auditing claims before publishing.

Place each claim by evidence strength and decision importance. Strong,
important claims need supplied proof. Weak or uncertain claims should become
caveats, questions, or evidence gaps.

## Assertive Ask And Weak-Tie Outreach

Best for respectful networking, referrals, client outreach, and follow-up.

- Assertive Ask: context, need, ask, opt-out or alternative.
- Weak-Tie Outreach Map: warm helpers, adjacent peers, alumni/community,
  aspirational strangers, and do-not-contact-yet.

Never turn these into bulk outreach or automated sending instructions.
