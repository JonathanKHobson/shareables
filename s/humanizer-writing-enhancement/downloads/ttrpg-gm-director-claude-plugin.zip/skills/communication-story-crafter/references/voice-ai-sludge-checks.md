# Voice And AI-Sludge Checks

Strong communication sounds specific to the person, audience, evidence, and
moment. Generic AI writing often sounds polished while saying little.

## Common AI-Sludge Signals

- Generic enthusiasm with no specific reason
- Buzzword piles
- Perfectly balanced but empty paragraphs
- Long setup before the actual ask
- Corporate phrases the user would not say aloud
- Too many abstract nouns
- Claims without proof
- No sign of actual audience, job, company, artifact, or situation context

## Voice Fidelity Audit

```markdown
## Voice Fidelity
- Sounds like the user: 1-5
- Too generic:
- Too corporate:
- Too detached:
- Too casual:
- Missing specific angle:
- Banned or weak phrases:
- Recommended revision:
```

## Make It Human Without Faking

Use:

- Specific context
- Real artifact or evidence
- Natural sentence rhythm
- Clear motive
- Appropriate vulnerability
- Concrete ask

Avoid:

- Fake confession
- False intimacy
- Exaggerated certainty
- Overly emotional setup
- “As someone passionate about...” unless the proof makes it real

## Raw-But-Cleaned Mode

Sometimes the best version is close to the user's raw note:

1. Remove filler.
2. Preserve the actual intent.
3. Move the ask up.
4. Add one proof sentence.
5. Cut any invented polish.

## Before And After

Weak:

```text
I am excited to express my interest in the role, as my skills and experience make me a strong fit.
```

Stronger:

```text
I’m interested in this role because it sits at the intersection I keep returning to: research, product clarity, and making complex workflows easier for people to act on.
```
