# Ethical Persuasion

Persuasion is ethical when it helps the audience understand, evaluate, decide,
or act with more clarity and agency.

## Ethical Influence Rules

- Show real sources and limits.
- Do not invent urgency.
- Do not inflate authority.
- Do not cherry-pick social proof.
- Do not use emotional pressure to cover weak evidence.
- Make the ask proportional to the relationship and proof.
- Let caveats travel with the claims they qualify.

## Trust Equation

```text
Trust = Credibility + Reliability + Empathy - Self-Interest Suspicion
```

Increase trust by:

- Naming the evidence.
- Being honest about uncertainty.
- Acknowledging tradeoffs.
- Demonstrating audience awareness.
- Making the next step low-friction and fair.

## Influence Principles, Used Carefully

| Principle | Ethical Use | Risky Use |
| --- | --- | --- |
| Authority | Cite real expertise or evidence. | Inflate credentials or certainty. |
| Social proof | Show comparable patterns honestly. | Cherry-pick impressive examples. |
| Consistency | Link to stated goals. | Trap the reader with past commitments. |
| Reciprocity | Provide value before asking. | Create guilt or obligation. |
| Unity | Emphasize shared purpose. | Use identity pressure. |
| Scarcity | Explain real constraints. | Manufacture urgency. |

## Red Flag Phrases

- “You will not believe...”
- “Everyone knows...”
- “Guaranteed...”
- “Only a fool would...”
- “If you really care about...”

Replace pressure with proof, specificity, and a fair ask.
