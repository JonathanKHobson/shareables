# Public Content Hooks

A hook is the opening move that gives a specific audience a reason to keep
reading, listening, or watching.

It is not a runtime callback, automation trigger, or platform hook. In this
skill, hook means a story or communication opener.

## What Good Hooks Do

1. Create relevance.
2. Create tension or curiosity.
3. Promise a meaningful payoff.

## Hook Pattern Library

| Hook Type | Formula | Use When |
| --- | --- | --- |
| Problem hook | Something important is breaking. | A reader already feels the pain or should. |
| Surprise hook | The result contradicts expectations. | Evidence challenges a common assumption. |
| Stakes hook | Here is what this could cost. | A decision, risk, or tradeoff is active. |
| Human moment | Show a person in context. | A pattern needs emotional or behavioral clarity. |
| Question hook | Ask the question everyone should ask. | The reader needs reframing. |
| Contrast hook | Before vs. after, old way vs. new way. | The change or insight is the story. |
| Myth-busting hook | Challenge a belief. | The audience has a misleading default model. |
| Identity hook | Connect to who the audience wants to be. | Professional values matter. |
| Visual hook | Show the pattern. | A diagram, artifact, or screenshot carries the point. |
| Decision hook | Make the decision explicit. | Stakeholders need action, not more background. |

## Audience Promise

Every hook should imply a promise:

```text
If you keep reading, you will understand / avoid / decide / see / learn / feel / do [specific payoff].
```

Weak:

```text
Here are some thoughts on AI workflow.
```

Stronger:

```text
The safest AI workflow I use is not the one with the most tools. It is the one with the clearest handoffs.
```

## Proof Types

Choose proof before polishing the hook:

- Workflow map
- Public demo
- Before/after example
- Hiring-manager perspective
- Research pattern
- User story
- Artifact caption
- Decision record
- Metric with caveat
- Mistake or lesson learned

## Ethical Hook Rules

A hook is ethical when:

- It accurately represents the message.
- It pays off the curiosity it creates.
- It does not exaggerate stakes.
- It does not hide uncertainty.
- It respects the reader's agency.

Avoid empty clickbait, fear bait, unsupported certainty, and hooks that promise
more proof than the message can supply.
