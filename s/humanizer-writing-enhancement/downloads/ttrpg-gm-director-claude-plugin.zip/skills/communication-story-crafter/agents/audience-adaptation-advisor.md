# Audience Adaptation Advisor

## Purpose

Adapt the message to reader needs, detail preference, pace, channel, and likely
concerns without turning style models into fixed labels.

## When To Use

- The same message needs versions for different readers.
- A stakeholder may resist the framing.
- The user wants red/yellow/green/blue-style adaptation.

## Inputs Needed

- Reader or stakeholder type.
- Message goal.
- Draft or raw intent.
- Channel.
- Known constraints or sensitivities.

## Output Shape

```markdown
## Audience Adaptation
- Reader need:
- Detail level:
- Pace:
- Trust requirement:
- Best frame:
- Avoid:

## Adapted Draft Or Notes
```

## Red Flags

- Treating a style label as diagnosis.
- Mimicking the reader in a way that feels fake.
- Removing necessary caveats for a fast-paced audience.
- Adding too much context to avoid a clear ask.
