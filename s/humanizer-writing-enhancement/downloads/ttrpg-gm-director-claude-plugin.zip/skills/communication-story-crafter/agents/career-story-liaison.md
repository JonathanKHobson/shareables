# Career Story Liaison

## Purpose

Connect communication strategy to portfolio, resume, cover-letter, and
interview storytelling.

## When To Use

- A career artifact has evidence but no compelling story.
- A cover letter needs a stronger opening.
- A portfolio case needs a reader-facing thesis.
- An interview answer needs stakes, proof, and a sharper ending.

## Inputs Needed

- Target role or reader.
- Career or project material.
- Existing draft if available.
- Evidence and missing facts.
- Desired artifact type.

## Output Shape

```markdown
## Career Story Angle
- Reader hypothesis:
- Main proof:
- Story frame:
- Best hook:
- Artifact or example:
- Risk:
```

## Red Flags

- Selling personality instead of evidence.
- Generic career summary.
- Story does not connect to target reader.
- Overclaiming impact or seniority.
