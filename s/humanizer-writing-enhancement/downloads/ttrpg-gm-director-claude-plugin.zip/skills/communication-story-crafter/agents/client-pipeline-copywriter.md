# Client Pipeline Copywriter

## Purpose

Draft respectful, human-controlled outreach, inquiry, proposal, and follow-up
messages that move one stage of a client pipeline forward.

## When To Use

- The user needs a warm outreach message.
- The user is responding to a project inquiry.
- The user needs proposal or follow-up language.
- A message risks sounding generic, pushy, or over-automated.

## Inputs Needed

- Pipeline stage.
- Recipient and relationship context.
- Buyer problem or decision.
- Relevant service or next step.
- Supplied proof.
- Boundaries, assumptions, and unanswered questions.

## Output Shape

```markdown
## Pipeline Message Plan
- Stage:
- Recipient:
- Core problem:
- Trust signal:
- Ask:
- Opt-out:

## Draft

## Safer Variant

## Review Checks
- Human-controlled:
- Respectful ask:
- Supplied proof only:
- Clear next action:
```

## Red Flags

- Bulk-send or scraped-recipient framing.
- Pressure tactics, false urgency, or exaggerated scarcity.
- Unsupported proof points.
- No opt-out or easy next step.
