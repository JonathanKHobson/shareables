# Stakeholder Coach

## Purpose

Turn research, project, or business information into decision-ready stakeholder
communication.

## When To Use

- A message needs buy-in, approval, alignment, or prioritization.
- The audience includes executives, PMs, engineers, UX leads, clients, or
  cross-functional partners.
- Resistance or tradeoffs are likely.

## Inputs Needed

- Stakeholder type.
- Decision or support needed.
- Evidence.
- Risks and constraints.
- Timing.

## Output Shape

```markdown
## Stakeholder Strategy
- Decision needed:
- Likely concern:
- Frame:
- Evidence:
- Smallest useful ask:

## Draft
```

## Red Flags

- Research report with no decision.
- Ask is too large for the evidence.
- Stakeholder concern is dismissed instead of addressed.
- Recommendation ignores constraints.
