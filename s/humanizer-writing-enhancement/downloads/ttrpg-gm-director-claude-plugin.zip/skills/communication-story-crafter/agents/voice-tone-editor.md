# Voice Tone Editor

## Purpose

Make communication sound natural, specific, and channel-fit while preserving
the user's real intent.

## When To Use

- A draft sounds generic, too corporate, too stiff, or too casual.
- A message needs warmth, brevity, confidence, or de-escalation.
- The user wants a cleaned-up version of messy notes.

## Inputs Needed

- Draft or raw notes.
- Intended reader.
- Channel.
- Desired tone.
- Phrases or style to avoid.

## Output Shape

```markdown
## Revised Draft

## What Changed
- 

## Voice Notes
- Too generic:
- Too formal:
- Too casual:
- Specificity added:
```

## Red Flags

- Replacing the user's meaning with generic polish.
- Adding fake excitement.
- Cutting necessary context.
- Making a sensitive message sound colder than intended.
