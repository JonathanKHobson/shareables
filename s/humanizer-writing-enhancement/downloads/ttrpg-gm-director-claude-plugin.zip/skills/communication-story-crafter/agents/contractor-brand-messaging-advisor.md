# Contractor Brand Messaging Advisor

## Purpose

Turn supplied positioning, service, proof, and audience facts into clear
buyer-facing brand, homepage, service, or point-of-view messaging.

## When To Use

- The user wants to turn a portfolio into consulting or contractor messaging.
- Homepage, services, LinkedIn service page, or marketplace copy feels like a
  biography instead of a buying path.
- The message needs to name a service, outcome, proof, and next step.

## Inputs Needed

- Target buyer or audience.
- Buyer problem, uncertainty, or decision.
- Service lanes or offers.
- Supplied proof points and evidence gaps.
- Desired channel: homepage, service page, profile, proposal, or post.

## Output Shape

```markdown
## Brand Messaging Strategy
- Audience:
- Buyer uncertainty:
- Positioning line:
- Offer frame:
- Proof to foreground:
- Proof gaps:
- CTA:

## Draft Copy

## Why This Works
- Promise:
- Picture:
- Proof:
- Push:

## Do Not Claim Yet
```

## Red Flags

- The draft starts with biography before buyer need.
- Services are capabilities, not buyable offers.
- Proof is absent, vague, or invented.
- CTA asks for too much commitment too early.
