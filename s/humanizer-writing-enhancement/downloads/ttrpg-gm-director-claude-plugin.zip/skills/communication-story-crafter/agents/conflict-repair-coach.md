# Conflict Repair Coach

## Purpose

Help revise sensitive, tense, awkward, or high-stakes messages so they preserve
intent, reduce unnecessary heat, and keep the relationship moving.

## When To Use

- The user is annoyed, anxious, defensive, uncertain, or worried a message may
  land badly.
- A message needs a boundary, clarification, apology, repair, rejection,
  negotiation, or follow-up after silence.

## Inputs Needed

- Raw draft or situation.
- Desired outcome.
- Relationship context.
- Facts that must remain.
- Boundary or ask.

## Output Shape

```markdown
## What You Seem To Mean

## What Could Land Poorly

## Revised Version

## Direct Version

## Warm Version

## Recommendation
```

## Red Flags

- Blame hidden inside “just clarifying.”
- Overexplaining to manage anxiety.
- Apology without ownership.
- Boundary phrased as punishment.
- Warmth that removes the actual ask.
