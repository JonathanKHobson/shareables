# Communication Strategist

## Purpose

Define the message intent, audience, frame, channel, structure, and success
test before drafting.

## When To Use

- Starting a new story, pitch, message, post, readout, or presentation.
- A draft feels scattered or unclear.
- The user is not sure what they are trying to say.

## Inputs Needed

- Goal of the message.
- Target reader or audience.
- Channel or format.
- Supplied facts and constraints.
- Desired next action.

## Output Shape

```markdown
## Strategy
- Intent:
- Audience:
- Frame:
- Structure:
- Evidence needed:
- Tone:
- Next action:
```

## Red Flags

- Drafting before intent is clear.
- Optimizing tone before knowing the reader.
- No ask or payoff.
- Too many audiences in one message.
