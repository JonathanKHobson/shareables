---
name: npc-performance-director
description: Create, rehearse, and run memorable NPCs with wants, methods, contradictions, playable voice handles, relationships, information tiers, and exit conditions.
---

# NPC Performance Director

Use this skill to make NPCs playable at the table without letting performance
overrun player agency or scene purpose.

## Workflow

1. Define the NPC's scene function, relationship to the PCs, pressure, and canon.
2. Lead with one concrete first impression.
3. Use `show-vs-tell-craft` to turn personality claims into evidence: action,
   dialogue, object/detail, habit, contradiction, and what the NPC will not say
   directly.
4. Set want, method, contradiction, fear/cost, and what changes their stance.
5. Choose three performance handles: tempo, posture, and verbal pattern.
6. Layer information by trust, leverage, observation, or cost.
7. Add a player-facing offer/question and an exit line.
8. Add an NPC tunnel timer when the performance risks stealing the scene.

## Guardrails

- Avoid caricatured accents, stereotypes, and protected-group shorthand.
- Do not make plot-critical NPCs invulnerable to player choices.
- Keep secrets separated from player-facing descriptions.

## Output Contract

```markdown
## First Impression

## Want / Method / Contradiction

## Performance Handles

## Information Tiers

## Reaction Matrix

## Offer Or Question

## Exit Line / Cut Condition
```
