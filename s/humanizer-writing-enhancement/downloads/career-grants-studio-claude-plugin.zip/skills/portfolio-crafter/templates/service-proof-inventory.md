# Service Proof Inventory Template

```markdown
## Service Proof Inventory

### Service Or Offer
- Name:
- Buyer problem:
- Outcome promised:
- Deliverables:
- Boundaries:

### Proof Candidates
| Proof item | Type | Service fit | Evidence strength | Permission | Use / cut / verify |
| --- | --- | --- | --- | --- | --- |
|  | artifact / metric / case / quote / process |  | strong / usable / weak | public / private / unknown |  |

### Strongest Proof Stack
1.
2.
3.

### Missing Proof
- [MISSING INFO: ...]

### Trust Strip Candidates
- 
- 

### Claims To Avoid
- 
```
