# Competency Evidence Map Template

```markdown
## Portfolio Strategy
- Target role:
- Reviewer type:
- Reviewer decision:
- Sharing context:
- Reader speed:

## Competency Evidence Map
| Competency | Evidence | Project/artifact | Gap | Revision |
| --- | --- | --- | --- | --- |
|  |  |  |  |  |

## Reviewer Questions
- What can this reviewer trust from the current evidence?
- What remains unsupported?
- What artifact, caption, or explanation would increase trust?

## Strongest Story

## Weakest Claim

## Next Revision Priority

## Do Not Claim Yet
- 
```
