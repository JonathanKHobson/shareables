# Reviewer Simulation Template

```markdown
## Simulation Setup
- Reviewer:
- Role or opportunity:
- Reader speed:
- Artifact reviewed:
- Decision the reviewer is making:

## Reviewer Response
1. Capability that seems credible:
2. Evidence that supports it:
3. Claim that feels vague or unsupported:
4. Question about role, method, impact, or ownership:
5. Confidentiality or trust concern:
6. Highest-leverage revision:

## Readiness
- Ready to share:
- Needs revision:
- Blocked until:

## Transfer
- Use in recruiter screen:
- Use in hiring-manager review:
- Use in interview:
- Use in deck or leave-behind:
```
