# Contractor Website Proof Plan Template

Use only when the user explicitly asks for website planning.

```markdown
## Website Proof Plan

- Target buyer:
- Core offer:
- Primary buyer problem:
- Proof standard:
- Website scope requested:

## Homepage Proof Hierarchy
1. Hero proof or promise:
2. Trust strip:
3. Service proof:
4. Case proof:
5. Process proof:
6. CTA:

## Service-To-Case Map
| Service | Buyer problem | Case/proof | Artifact | Missing proof |
| --- | --- | --- | --- | --- |
|  |  |  |  |  |

## Case Cards Needed
- 
- 

## Redaction And Permission Notes
- 

## Do Not Design Yet
- Claims to verify:
- Proof to source:
- Private items to remove:
```
