# Portfolio Template Index

Choose the smallest template that fits the task.

| Need | Template |
| --- | --- |
| Full portfolio case study | `case-study.md` |
| One-page project summary | `case-card.md` |
| Competency-to-proof map | `competency-evidence-map.md` |
| Target reviewer simulation | `reviewer-simulation.md` |
| Scaffolded portfolio practice path | `portfolio-faded-scaffold.md` |
| Audit visitor journey and core loop of trust | `visitor-core-loop-audit.md` |
| Plan a portfolio playtest or reviewer observation | `portfolio-playtest-protocol.md` |
| Caption several artifacts | `artifact-caption-set.md` |
| Prepare an interview presentation | `interview-deck-outline.md` |
| Create a controlled follow-up artifact | `leave-behind.md` |
| Frame AI workflow or automation-adjacent work | `ai-workflow-case.md` |
| Frame UX research, audit, or discovery work | `ux-research-case.md` |
| Create a buyer-facing contractor proof card | `contractor-case-card.md` |
| Inventory proof for a service or offer | `service-proof-inventory.md` |
| Audit the five-minute buyer reader path | `buyer-reader-path.md` |
| Plan website proof only after explicit website request | `contractor-website-proof-plan.md` |

## Default Choice

If evidence is messy, start with `case-card.md`. If the user already has solid facts and artifacts, use `case-study.md`.
