# Contractor Case Card Template

```markdown
## [Case Or Service Proof Title]

- Target buyer:
- Buyer problem:
- Decision or uncertainty:
- Service lane:
- Role and responsibility:
- Context:
- Constraints:
- Method or approach:
- Artifacts or deliverables:
- Findings or recommendations:
- Decision influenced:
- Outcome, learning, or risk reduced:
- What this proves to a client:
- CTA fit:
- Confidentiality:
- Missing proof:
- Do not claim yet:
```

## Completion Check

The proof card is ready for review when it names a buyer problem, a defensible
role, at least one proof artifact, and a safe next action without inventing
metrics or client claims.
