# Visitor Core Loop Audit

## Context

- Portfolio, case, or artifact:
- Target visitor:
- Visitor decision:
- Sharing context:

## Core Loop Of Trust

| Beat | Current Experience | Evidence / Feedback | Friction | Revision |
| --- | --- | --- | --- | --- |
| Arrival |  |  |  |  |
| Understand who/what this proves |  |  |  |  |
| Choose a case or path |  |  |  |  |
| Inspect process and artifacts |  |  |  |  |
| Trust evidence and ownership |  |  |  |  |
| Remember the signal |  |  |  |  |
| Contact or next action |  |  |  |  |

## Interaction Review

- Interaction that helps:
- Interaction that obstructs:
- Accessibility or performance risk:
- Anti-gimmick note:

## Next Revision

## Missing Evidence
