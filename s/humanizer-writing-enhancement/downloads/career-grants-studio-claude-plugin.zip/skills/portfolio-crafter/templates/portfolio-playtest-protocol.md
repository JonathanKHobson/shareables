# Portfolio Playtest Protocol

## Study Frame

- Portfolio artifact:
- Target reviewer or visitor:
- Question to test:
- Sharing context:
- What counts as success:

## Task

Ask the reviewer to complete one realistic task, such as:

```markdown
Find evidence that this person can do [target capability] for [target context].
```

## Observation Notes

| Moment | Visitor Action | Evidence | Confusion / Trust Gap | Severity | Revision Hypothesis |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |

## Retrospective Questions

- What do you think this person is strongest at?
- What evidence convinced you?
- What felt vague, missing, or hard to trust?
- What did you expect to find but could not?
- What would make the next action easier?

## Report

- Top finding:
- Evidence:
- Revision:
- Confidence:
- Accessibility or confidentiality note:

## Boundary

If no real reviewer participated, label the output as a reviewer simulation,
not playtest evidence.
