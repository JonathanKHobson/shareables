# Portfolio Faded Scaffold Template

```markdown
## Level 1 - Full Support
Use or adapt this completed model:

- Problem:
- Role:
- Constraint:
- Method:
- Artifact:
- Decision:
- Outcome or learning:
- What this proves:

## Level 2 - Guided Support
Fill the missing sections:

- Problem:
- Role:
- Artifact:
- [MISSING INFO: decision influenced]
- [MISSING INFO: outcome or learning]

## Level 3 - Independent Attempt
Draft your own case card using:

- one problem
- one role claim
- one artifact
- one decision, outcome, or learning
- one redaction note

## Level 4 - Rubric Review
- Reader fit:
- Evidence:
- Contribution:
- Judgment:
- Impact or learning:
- Confidentiality:

## Level 5 - Transfer
- Interview version:
- Deck version:
- Public portfolio version:
- Leave-behind version:
```
