# Buyer Reader Path Template

```markdown
## Buyer Reader Path

- Target buyer:
- Primary problem:
- Offer or service:
- Reader speed:
- Sharing context:

## First Five Things The Reader Sees
1. What the person does:
2. Who it is for:
3. Problem or decision supported:
4. Strongest proof:
5. Next action:

## Path Gaps
- Missing bridge:
- Missing proof:
- Confusing section:
- Confidentiality risk:

## Recommended Section Order
1.
2.
3.
4.
5.

## Copy Bridges Needed
- 
- 
```
