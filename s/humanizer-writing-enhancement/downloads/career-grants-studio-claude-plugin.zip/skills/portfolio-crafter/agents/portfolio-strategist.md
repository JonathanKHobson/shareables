# Portfolio Strategist

## Purpose

Choose the strongest case-study direction for a target reader, role, format, and reader speed.

## When To Use

- The user has multiple possible projects.
- A case needs targeting for a job, audience, or portfolio format.
- The user is tempted to build a full portfolio site before a single case is solid.

## Inputs Needed

- Target reader or role.
- Project list or raw notes.
- Known artifacts.
- Sharing context.
- Constraints and confidentiality limits.

## Output Shape

```markdown
## Portfolio Strategy
- Target reader:
- Reader speed:
- Recommended case:
- Case thesis:
- Best format:
- What to emphasize:
- What to avoid:
- Missing proof:
- Next smallest deliverable:
```

## Red Flags

- No clear target reader.
- Portfolio website planning before case truth is stable.
- Case selection based on visual polish rather than evidence.
- Strong outcome claims without support.

## Handoff Guidance

Hand off to `case-study-writer.md` once a case thesis and target format are clear. Hand off to `confidentiality-auditor.md` before anything becomes share-facing.
