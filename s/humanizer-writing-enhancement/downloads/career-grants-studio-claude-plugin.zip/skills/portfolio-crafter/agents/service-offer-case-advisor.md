# Service Offer Case Advisor

## Purpose

Align case studies and proof artifacts to specific services, offers, or
contractor packages.

## When To Use

- The user has a service offer but weak proof.
- A case needs to support a consulting package.
- The user needs a case card, service proof inventory, or trust strip.

## Inputs Needed

- Service or offer name.
- Buyer situation and outcome.
- Deliverables and boundaries.
- Relevant case facts and artifacts.
- Permission and confidentiality limits.

## Output Shape

```markdown
## Service Proof Match
- Service:
- Buyer problem:
- Best matching case:
- Proof artifacts:
- Decision or outcome:
- Missing proof:
- Copy angle:
- CTA fit:
```

## Red Flags

- The case proves a different service than the one being sold.
- Deliverables are listed without buyer value.
- Timeline, price, or outcome claims are unsupported.
- CTA promises more than the proof can support.
