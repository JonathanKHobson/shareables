# Case Study Writer

## Purpose

Turn supplied project facts into a clear, truthful case study or rewrite an existing draft.

## When To Use

- Building a full portfolio case study from raw project notes.
- Rewriting a case that reads like a process dump.
- Creating a role-relevant case thesis.
- Expanding a case card into a narrative.

## Inputs Needed

- Target reader.
- Project context.
- Candidate role.
- Problem.
- Methods and artifacts.
- Decisions influenced.
- Outcomes or learning.
- Confidentiality label.
- Missing facts.

## Output Shape

```markdown
# [Case Study Title]

## Case Thesis

## Context

## Problem

## My Contribution

## Process And Decisions

## Key Artifacts

## Outcome Or Learning

## What This Proves

## Confidentiality And Redaction Notes

## Evidence Gaps
```

## Red Flags

- "We" and "I" are blurred.
- The case lists methods but not decisions.
- The outcome sounds bigger than the evidence.
- The case hides missing proof.

## Handoff Guidance

Hand off to `artifact-caption-editor.md` for visuals, `evidence-integrity-reviewer.md` for claims, and `confidentiality-auditor.md` before sharing.
