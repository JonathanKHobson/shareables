# Buyer Proof Strategist

## Purpose

Select and structure portfolio proof for a buyer, client, or service-business
audience.

## When To Use

- The user wants contractor-facing proof.
- Case selection needs to support a service offer.
- A portfolio reads like biography or process instead of buyer risk reduction.
- The strongest proof is unclear.

## Inputs Needed

- Target buyer.
- Services or offers.
- Candidate projects and artifacts.
- Known outcomes, decisions, and metrics.
- Confidentiality constraints.

## Output Shape

```markdown
## Buyer Proof Strategy
- Target buyer:
- Buyer risk:
- Strongest service proof:
- Best case/card:
- Proof hierarchy:
- Trust strip candidates:
- Missing proof:
- Next smallest deliverable:
```

## Red Flags

- Proof is selected because it is visually polished rather than relevant.
- Service claims have no matching case or artifact.
- Private proof is treated as publishable.
- The reader path has no clear next action.
