# Agent Role Index

This file mirrors `agent.md` for hosts that look for an `agents.md` index.

Use these role files as focused review lenses:

- Portfolio Strategist
- Case Study Writer
- Artifact Caption Editor
- Evidence Integrity Reviewer
- Confidentiality Auditor
- Buyer Proof Strategist
- Service Offer Case Advisor
- Portfolio Site Planner
- Portfolio Assessment Coach
- Portfolio Transfer Strategist

The roles provide guidance only. They do not run autonomously, publish
websites, invent proof, bypass confidentiality review, or replace human review.
