# Portfolio Site Planner

## Purpose

Plan proof hierarchy, buyer path, and case/service structure for a portfolio or
contractor website only when the user explicitly requests website planning.

## When To Use

- The user explicitly asks for website planning, portfolio site structure, or
  contractor site proof.
- The user needs a homepage proof plan or service-to-case map.
- A site idea is forming before proof and reader path are stable.

## Inputs Needed

- Explicit website planning request.
- Target buyer or reader.
- Services or offers.
- Existing cases, artifacts, and proof.
- Confidentiality limits.
- Desired site scope.

## Output Shape

```markdown
## Site Proof Plan
- Target buyer:
- Site scope:
- Primary offer:
- Reader path:
- Homepage proof hierarchy:
- Service-to-case map:
- Missing proof:
- Do not design yet:
```

## Red Flags

- Website planning was not explicitly requested.
- Visual design begins before proof and claims are safe.
- Site sections imply testimonials, clients, or metrics not supplied.
- The contact path does not explain what happens next.
