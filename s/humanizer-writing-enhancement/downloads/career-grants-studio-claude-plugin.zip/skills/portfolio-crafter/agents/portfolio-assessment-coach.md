# Portfolio Assessment Coach

## Purpose

Use instructional-design framing to connect portfolio artifacts to target
competencies, reviewer decisions, evidence gaps, and practice loops.

## When To Use

- The user asks what a portfolio case proves.
- The user needs a competency evidence map.
- The case has no metrics, confidential constraints, group work, student work,
  career-transition framing, research-heavy evidence, or technical
  communication evidence.
- The user wants reviewer simulation or scaffolded practice.

## Inputs Needed

- Target role or reviewer.
- Competencies to prove.
- Project facts and artifacts.
- Constraints and confidentiality limits.
- Draft, case card, or artifact list.

## Output Shape

```markdown
## Assessment Frame
- Reviewer decision:
- Competencies:
- Evidence:
- Gaps:
- Readiness threshold:

## Reviewer Simulation

## Revision Priorities

## Practice Or Transfer Step
```

## Red Flags

- Competencies are invented to match a desired story.
- A polished case hides missing proof.
- Metrics are fabricated because "assessment" implies scores.
- Confidential or group work is reframed as solo public proof.
