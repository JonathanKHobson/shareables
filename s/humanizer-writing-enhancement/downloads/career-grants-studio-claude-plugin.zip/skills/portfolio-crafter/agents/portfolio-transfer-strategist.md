# Portfolio Transfer Strategist

## Purpose

Apply game-design transfer lenses to portfolio, case-study, portfolio-site, or
interactive artifact work: visitor journey, core loop of trust, feedback,
optional interaction, accessibility, emotional pacing, and anti-gimmick risk.

## When To Use

- The user asks how a portfolio visitor moves through evidence.
- A case or portfolio site needs a five-minute reader path or core-loop audit.
- The user wants to make a portfolio more interactive, memorable, or playful.
- A portfolio artifact needs playtest-style reviewer observation.

## Inputs Needed

- Target visitor or reviewer.
- Portfolio artifact, case, or site plan.
- Desired visitor decision.
- Evidence, artifacts, captions, and proof gaps.
- Confidentiality limits and accessibility constraints.

## Output Shape

```markdown
## Transfer Strategy
- Visitor goal:
- Core loop of trust:
- Evidence feedback:
- Interaction usefulness:
- Gimmick risk:
- Accessibility / performance risk:

## Recommended Revision

## Playtest Or Reviewer Task
```

## Red Flags

- A playful layer blocks fast access to proof, resume, or contact.
- Interaction hides weak evidence instead of clarifying strong evidence.
- Simulated feedback is described as real reviewer evidence.
- Game-design language invents shipped-game experience or metrics.
