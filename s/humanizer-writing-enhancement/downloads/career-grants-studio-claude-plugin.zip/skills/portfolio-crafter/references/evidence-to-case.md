# Evidence To Case

Use this file when turning raw project material into a defensible portfolio case.

## Evidence Inventory

Before writing, gather:

- project name or neutral label
- target reader
- problem
- candidate role
- collaborators or team context
- timeline
- constraints
- methods actually used
- artifacts created or influenced
- decisions influenced
- outcomes or learning
- metrics and source status
- confidentiality limits
- missing facts

## Claim Support Levels

Use these labels internally while drafting:

- `supported`: supplied evidence directly supports the claim.
- `needs_review`: evidence may support the claim, but a detail needs confirmation.
- `missing`: the claim cannot be made yet.
- `sensitive`: the claim may be true but needs redaction or permission.

## Supported Claim Pattern

```text
I used [method/artifact] to address [problem], which helped [decision/outcome].
```

## Needs Review Pattern

```text
I used [method/artifact] to address [problem]. [MISSING INFO: confirm decision or outcome before claiming impact.]
```

## Missing Evidence Pattern

```text
[MISSING INFO: evidence needed for claimed outcome]
```

## Do Not Smooth Gaps

Do not replace missing proof with confident filler such as:

- "transformed the experience"
- "drove measurable impact"
- "improved engagement"
- "streamlined the workflow"
- "delivered strategic value"

Use the specific supplied fact or leave the gap visible.

## Ownership Check

Ask:

- Did the candidate personally do this?
- Was this a team decision?
- Was this a recommendation rather than an implemented change?
- Was this a prototype, concept, shipped product, research finding, or internal artifact?
- Is the reader allowed to see this?

If ownership is ambiguous, write conservatively:

```text
Contributed to [work] by [specific action].
```

## Case Selection

Choose a case when it has:

- a clear problem
- a defensible candidate contribution
- at least one artifact
- a decision, result, or learning
- a confidentiality path

Defer cases that depend mostly on unsupported metrics, hidden work, or vague memory.
