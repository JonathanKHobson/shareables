# Service Proof And Contractor Case Studies

Use this reference for contractor-facing case cards, service proof inventories,
trust strips, and proof sections.

## Contractor Case Structure

1. Client, team, or project context.
2. Problem, decision, or uncertainty.
3. Role and responsibility.
4. Approach or method.
5. Insights, findings, or patterns.
6. Recommendations.
7. Outcome, learning, or decision influenced.
8. Artifacts or deliverables.
9. What this shows about working with the person.

If the user cannot share the client or organization, use a privacy-safe
descriptor and mark what cannot be claimed.

## Proof Hierarchy

1. Verified outcome, decision, or business/user impact.
2. Specific metric or before/after evidence.
3. Artifact, deliverable, or sample work.
4. Method proof or process evidence.
5. Tool list, credential, or self-description.

Foreground the highest supported proof. Do not inflate weak proof with stronger
language.

## Proof Without Testimonials

When testimonials or logos are unavailable, use:

- artifact proof
- method proof
- decision proof
- before/after examples
- public writing
- anonymized project context
- clear process and deliverables

Mark any missing permission, metric, or result as `[MISSING INFO: ...]`.

## Case Card For Buyers

```markdown
## [Project Or Service Proof]

**Problem:** [What was unclear, broken, risky, or undecided?]

**Situation:** [Who needed help and why, using share-safe language.]

**Role:** [What the person owned.]

**Method:** [What was done and why.]

**Findings Or Recommendations:**
- [Finding/recommendation]
- [Finding/recommendation]
- [Finding/recommendation]

**What Changed:** [Decision, recommendation, roadmap, learning, or next step.]

**Proof:** [Artifacts, deliverables, metrics, quotes, or examples.]

**Why It Matters:** [Buyer/user value.]

**Missing Or Private:** [Gaps, redactions, permissions.]
```

## Trust Strip Inputs

Use only supplied proof:

- number of studies, interviews, participants, responses, or artifacts
- domains or problem types
- project types
- deliverables created
- decisions influenced
- tools only when relevant to buyer trust

Do not use brand names, logos, testimonials, or statistics without permission
or supplied evidence.
