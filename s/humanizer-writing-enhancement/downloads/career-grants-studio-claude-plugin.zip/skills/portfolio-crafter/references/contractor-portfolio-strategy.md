# Contractor Portfolio Strategy

Use this reference when portfolio material needs to support consulting,
contractor, service-business, or client-facing work.

## Core Reframe

A hiring portfolio asks, "Can this person do the work?" A contractor-facing
portfolio also asks, "Can this person solve my problem without creating chaos?"

Shift emphasis:

| Portfolio framing | Contractor proof framing |
| --- | --- |
| Projects | Client or team problems solved |
| Role | Responsibility and decision impact |
| Process | Repeatable method a buyer can trust |
| Skills | Services and outcomes |
| Screenshots | Evidence, artifacts, and deliverables |
| About | Why the approach reduces risk |
| Contact | Clear inquiry or fit-call path |

## Buyer Path

For contractor use, a portfolio or proof section should help a buyer answer:

- What problem does this person solve?
- What kind of service can I buy?
- What proof shows they can handle ambiguity?
- What will happen after I contact them?
- What risks, constraints, and boundaries are visible?

## Five-Minute Reader Path

Check the first five things a buyer sees:

1. What the person does.
2. Who the work is for.
3. What problem or decision the work supports.
4. One strong proof point or case.
5. A clear next action.

If any step is missing, write the missing bridge before adding more cases.

## Service-Proof Match

For each service or offer, map:

```text
Service -> buyer problem -> relevant case -> proof artifact -> decision influenced -> evidence gap
```

Do not use an attractive artifact if it does not support the service claim.

## Website Boundary

Do not plan a public website unless the user explicitly asks for website
planning. When they do, keep the work proof-first:

- homepage proof hierarchy
- service-to-case mapping
- inquiry path
- confidentiality and redaction
- missing proof

Visual design comes after proof and reader path are stable.
