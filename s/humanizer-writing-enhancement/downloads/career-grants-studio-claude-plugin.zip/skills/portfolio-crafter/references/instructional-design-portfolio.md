# Instructional Design For Portfolios

Use this reference when a portfolio needs to prove capability, not merely look
polished. A portfolio is an assessment artifact: it helps a reviewer infer
competence from evidence.

## Outcome, Evidence, Output

Before drafting, define:

```yaml
portfolio_alignment:
  target_role:
  reviewer_type:
  reviewer_decision:
  competencies_to_prove:
  evidence_available:
  evidence_gaps:
  output_format:
  readiness_threshold:
```

Do not invent competencies, metrics, roles, or results to satisfy the map.

## Competency Evidence Map

Use a table:

| Competency | Evidence | Project/artifact | Gap | Revision |
| --- | --- | --- | --- | --- |

Strong competencies are observable. Prefer "research planning," "synthesis,"
"stakeholder translation," "AI evaluation guardrails," or "technical
communication" over vague labels such as "strategic thinker."

## Reviewer Simulation

Act as the target reviewer and answer:

1. What capability seems credible?
2. What claim is unsupported?
3. What question remains about role, method, impact, or ownership?
4. What artifact would increase trust?
5. What is the highest-leverage revision?

## Special Support Paths

- **No metrics:** use decision, learning, adoption, risk reduction, or artifact
  proof. Do not make up numbers.
- **Confidential work:** generalize context, redact specifics, and foreground
  method and judgment.
- **Group projects:** name role, contribution, and shared ownership carefully.
- **Student projects:** present realistic constraints and demonstrated skill
  without pretending it was client work.
- **Career transition:** connect prior evidence to target competencies.
- **Research-heavy portfolios:** foreground questions, methods, synthesis,
  recommendations, and decisions.
- **Visual design-heavy portfolios:** explain rationale, constraints, and
  evaluation, not only visuals.
- **Technical communication portfolios:** show audience, information problem,
  structure, clarity, and adoption/use.

## Faded Scaffold

Use this when the user wants to learn or repeatedly improve cases:

1. Full model case card.
2. Partial case template.
3. Independent draft prompt.
4. Rubric review.
5. Transfer to interview, deck, or leave-behind.

## Cognitive Load And Transfer

Check whether the case works at three speeds:

- 10-second scan: title, role, case thesis, strongest proof.
- 2-5 minute review: problem, contribution, artifacts, decision, outcome.
- Deep review: tradeoffs, constraints, evidence, reflection.

End with how to adapt the case for a recruiter screen, hiring-manager review,
interview story, deck, or public portfolio.
