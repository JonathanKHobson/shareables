# Game Design Transfer For Portfolios

Use this reference when a portfolio, case study, portfolio-site plan, or
interactive artifact needs better visitor journey, evidence feedback, emotional
pacing, accessibility, or anti-gimmick review. The goal is not to make a
portfolio into a game. The goal is to borrow game-design discipline: clear
goals, readable choices, immediate feedback, purposeful progression, and
playtesting as evidence.

## Portfolio Visitor Loop

A portfolio has a trust loop:

```txt
Arrive -> understand the candidate -> choose a case -> trust the process -> see evidence -> remember the signal -> contact or share
```

Audit each beat:

| Beat | Portfolio Question |
| --- | --- |
| Arrival | What can the visitor understand in 30 seconds? |
| Navigation | Can they choose a case by role, skill, or proof need? |
| Case study | Does the arc move from problem to constraints to action to evidence to outcome? |
| Evidence | Does each claim get feedback through artifacts, captions, decisions, or outcomes? |
| Memory | What should the visitor remember after leaving? |
| Contact | Is the win condition obvious and low friction? |

## MDA Transfer

| Game Layer | Portfolio Equivalent |
| --- | --- |
| Mechanics | Links, filters, case structure, scroll, media, captions, CTA. |
| Dynamics | Visitor skims, compares, deep-dives, checks credibility, and builds trust. |
| Aesthetics | Clarity, credibility, curiosity, confidence, and appropriate delight. |

## Portfolio Playtest Protocol

Use lightweight observation before major rewrites:

1. Give the reviewer one task, such as "Find evidence that this person can do the target work."
2. Observe without helping.
3. Note where they pause, miss proof, misread ownership, or lose trust.
4. Ask what they remember after two minutes.
5. Convert findings into structure, caption, ordering, or proof changes.

Do not present simulated review as real playtest evidence. Mark it as a
simulation unless an actual reviewer participated.

## Anti-Gimmick Guardrails

Helpful interaction:

- makes evidence easier to find;
- clarifies progression through a case;
- gives immediate state feedback;
- keeps optional depth accessible;
- supports keyboard, screen reader, reduced-motion, and low-bandwidth needs.

Risky interaction:

- forces a mini-game before evidence or contact details;
- hides proof behind clever navigation;
- uses progress bars, badges, or unlocks without real meaning;
- slows recruiters, clients, or hiring managers;
- creates motion, contrast, or input barriers;
- makes serious work feel trivial.

## Output Check

Before recommending playful or interactive portfolio treatment, confirm:

- the conventional evidence path still works;
- the interaction has a job beyond novelty;
- accessibility and performance risks are visible;
- confidentiality has been checked;
- claims still come only from supplied evidence.
