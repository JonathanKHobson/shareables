# Knowledge Atlas Portfolio Activities

Use these compact activities when the user needs movement before polish. They
are adapted from Knowledge Atlas and File-O-Fun style practical patterns.

## One-Screen Case Skeleton

Use when a case feels too large to start.

Fill one screen only:

- problem
- role
- users or audience
- evidence
- constraints
- action
- result or learning
- reflection
- proof artifacts

Mark gaps as `[NEEDS EVIDENCE]`, `[NEEDS VISUAL]`, or `[NEEDS PERMISSION]`.

## Artifact Caption Sprint

Use when artifacts exist but do not prove anything yet.

For each artifact, write:

- what it is
- what it shows
- why it mattered
- what decision or recommendation it influenced
- redaction or permission note

Keep captions factual before making them polished.

## Proof Stack Ranking

List 8-12 possible proof items. Score each as `strong`, `usable`, `weak`, or
`private` across:

- reader relevance
- clarity
- evidence quality
- permission safety
- uniqueness

Use the top three as visible proof. Archive weak sentimental artifacts.

## Five-Minute Reader Path

Trace what a busy reader sees in five minutes:

1. landing statement
2. strongest case or proof card
3. proof artifact
4. about/contact or inquiry path
5. next action

Write the missing bridge labels or section intros before adding more content.

## Evidence Tagging Pass

Tag each claim:

- `[SUPPORTED]`
- `[ESTIMATED]`
- `[PRIVATE]`
- `[MISSING]`
- `[OVERCLAIM]`

Rewrite overclaims into supported claims, caveats, or evidence requests.

## Narrative Arc Map

For a case that reads like a process dump, map:

```text
Uncertainty -> method -> pattern -> recommendation -> decision -> proof
```

If a step is missing, keep the gap visible.
