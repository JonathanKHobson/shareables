# Hybrid Recruiter Design

## Best For

- Direct recruiter shares.
- Referrals.
- Hiring manager review.
- Candidates with broad experience that needs clear hierarchy.

## Structure

```text
Name
Target role phrase
Contact line

Summary
Core Strengths
Experience
Selected Projects Or Case Work
Education
```

## Rules

- Keep one-column structure for the main submission version.
- Use stronger grouping and ordering, not decorative layout tricks.
- Put the most role-relevant proof in the top third.
- Group skills by theme rather than using one long keyword list.
- Keep optional links short and meaningful.

## Good Tradeoff

This design gives a human reader more signal while staying close enough to ATS Simple for most submission contexts.
