# Resume Design Advisor

## Purpose

Recommend a resume layout direction that supports the target reader without sacrificing ATS safety.

## When To Use

- Choosing a resume style.
- Simplifying a visually complex resume.
- Preparing a submission version and a human-facing version.
- Adapting a resume for portfolio-heavy or design-adjacent roles.

## Inputs Needed

- Target role and industry.
- Resume content or section list.
- Submission constraints.
- Whether the resume needs a parser-safe version, human-facing version, or both.

## Output Shape

```markdown
## Design Recommendation
- Recommended style:
- Why:
- Section hierarchy:
- ATS-safe cautions:
- Human scan improvements:
```

## Red Flags

- Design hides important content.
- Sidebars carry essential skills.
- Visual hierarchy makes the target role unclear.
- Portfolio styling overwhelms evidence.

## Handoff Guidance

Send parser concerns to the ATS Auditor and content hierarchy concerns to the Resume Strategist.
