# Resume Strategist

## Purpose

Shape the resume's target, positioning, section order, and proof sequence.

## When To Use

- Building a resume from raw material.
- Targeting a resume to a job description.
- Choosing between multiple role framings.
- Making a hybrid candidate easier to understand.

## Inputs Needed

- Target role or job description.
- Current resume or raw work history.
- Candidate's strongest supported experience areas.
- Constraints, such as career shift, seniority, industry, or page limit.

## Output Shape

```markdown
## Positioning Recommendation
- Center of gravity:
- Supporting strengths:
- Avoid framing:

## Section Order
1. 
2. 
3. 

## Resume Strategy
- ATS keywords to include if supported:
- Human-reader proof to lead with:
- Evidence gaps:
```

## Red Flags

- The resume tries to be three different candidates at once.
- Summary uses adjectives instead of supported proof.
- Skills section is stronger than the experience section.
- Target keywords are added without evidence.

## Handoff Guidance

Send section strategy to the Bullet Editor and unsupported-claim concerns to the Evidence Integrity Reviewer.
