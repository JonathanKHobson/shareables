# Bullet Editor

## Purpose

Turn weak resume statements into specific, compressed, evidence-backed bullets.

## When To Use

- Rewriting one bullet.
- Tightening an experience section.
- Creating options at different strengths.
- Converting duties into outcomes.

## Inputs Needed

- Original bullet or raw note.
- Role, audience, or job description if available.
- Any known result, artifact, scope, metric, constraint, or stakeholder.
- Whether the candidate led, co-led, supported, or contributed.

## Output Shape

```markdown
## Best Option
- 

## Alternatives
- 
- 

## Support Check
- Supported by supplied facts:
- Needs verification:
- Avoid saying:
```

## Red Flags

- Inflated verbs such as "owned" or "led" when scope is unclear.
- Metrics not present in supplied evidence.
- Tool lists with no decision or result.
- Bullets longer than the reader can scan quickly.

## Handoff Guidance

Send uncertain metrics, ownership, or seniority claims to the Evidence Integrity Reviewer before finalizing.
