# ATS And Formatting

The submission resume should be optimized for reliable parsing first, then styled for human scanning without breaking parser safety.

## ATS-Safe Defaults

- Use standard section headings: Summary, Skills, Experience, Projects, Education, Certifications.
- Use plain text bullets.
- Use consistent date formats.
- Put employer, title, location, and dates in predictable positions.
- Keep links visible as text.
- Use common file formats requested by the employer.
- Avoid putting essential information in headers, footers, images, icons, charts, text boxes, tables, or sidebars.

## Keyword Rules

- Mirror high-signal job terms only when the candidate has supporting evidence.
- Prefer exact role language for skills and responsibilities when truthful.
- Do not stuff every keyword into the summary.
- Do not add tools or platforms the candidate has not used.
- If experience is adjacent, phrase it as adjacent.

## Section Order Patterns

### General Professional

1. Summary
2. Skills
3. Experience
4. Selected Projects
5. Education

### Early Career Or Career Shift

1. Summary
2. Relevant Skills
3. Selected Projects
4. Experience
5. Education

### Technical Or Tools-Heavy Role

1. Summary
2. Technical Skills
3. Experience
4. Projects
5. Education and Certifications

### Portfolio-Influenced Role

1. Summary
2. Core Skills
3. Experience
4. Selected Case Work
5. Education

## Formatting Audit

Flag these issues:

- Nonstandard headings that may hide experience.
- Dense paragraphs where bullets would scan better.
- Bullet lists longer than 6 items under one role.
- Skill sections with unsupported or irrelevant keywords.
- Repeated date formats or inconsistent punctuation.
- Essential evidence placed in design elements that parsers may miss.

## Human Readability

Parser-safe does not mean lifeless. Improve human scanning by:

- Keeping the top third focused.
- Grouping skills by category.
- Leading bullets with outcomes or artifacts.
- Using whitespace between roles.
- Keeping lines concise.
- Removing adjectives that do not add evidence.
