# Generic Phrase Guardrails

These phrases are warnings for resume drafting and review. They are not forbidden in every possible context, but they usually signal generic polish instead of proof.

## Risky Phrases

- `passionate about`
- `proven track record`
- `results-driven`
- `dynamic`
- `innovative professional`
- `highly motivated`
- `detail-oriented`
- `leveraging cutting-edge`
- `fast-paced environment`
- `team player`
- `wear many hats`
- `uniquely qualified`
- `game changer`
- `thought leader`
- `AI-powered`
- `seamless`
- `robust`
- `synergy`

## Rewrite Pattern

Instead of:

```text
Results-driven professional with a proven track record of success.
```

Use:

```text
Operations analyst who standardizes ambiguous workflows, clarifies decision points, and turns stakeholder input into repeatable execution plans.
```

## Review Questions

- What specific evidence proves the claim?
- What reader problem does this sentence answer?
- Could the candidate defend this calmly in an interview?
- Is this phrase doing work, or only adding polish?
- Is the sentence true without sounding smaller than the evidence deserves?
