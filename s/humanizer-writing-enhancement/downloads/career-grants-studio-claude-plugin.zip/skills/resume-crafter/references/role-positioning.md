# Role Positioning

Use these templates to choose a resume's center of gravity. Adapt them only when the user's supplied evidence supports the framing.

## UX Research

- Positioning: researcher who turns user evidence into product decisions.
- Section order: Summary, UX Research Skills, Experience, Selected Research Cases, Education.
- Proof sequence: method, participants or artifact, decision influenced, outcome or learning.
- Avoid: listing methods without decisions, unsupported product ownership.

## Product Or UX Design

- Positioning: designer who connects user needs, constraints, prototyping, and delivery.
- Section order: Summary, Design Skills, Experience, Selected Design Cases, Education.
- Proof sequence: problem, artifact, constraint, iteration or handoff, outcome.
- Avoid: visual polish claims without artifacts, overstated design-system ownership.

## Product Management Or Product Operations

- Positioning: product/workflow translator who connects discovery, prioritization, metrics, and delivery.
- Section order: Summary, Product Skills, Experience, Selected Product Work, Education.
- Proof sequence: stakeholder problem, analysis or prioritization method, decision, business or user impact.
- Avoid: claiming formal product ownership when evidence only supports adjacent contribution.

## Business Analysis Or Operations

- Positioning: analyst who turns ambiguous workflows into clear requirements, decisions, and measurable improvements.
- Section order: Summary, Analysis Skills, Experience, Workflow Projects, Education.
- Proof sequence: business problem, inputs, analysis method, recommendation, measurable or observable impact.
- Avoid: inflated ROI, unsupported executive-decision ownership.

## AI Workflow Or Automation

- Positioning: workflow builder focused on practical value, guardrails, evaluation, and adoption.
- Section order: Summary, AI Workflow Skills, Experience, AI/Automation Projects, Education.
- Proof sequence: workflow pain, intervention, guardrail or evaluation, measured or observed impact.
- Avoid: invented model expertise, vague "AI-powered" language, hidden automation framing.

## Technical Communication Or Content Design

- Positioning: communicator who makes complex information usable for a specific audience.
- Section order: Summary, Communication Skills, Experience, Selected Artifacts, Education.
- Proof sequence: audience need, information architecture, artifact, decision or comprehension outcome.
- Avoid: generic writing strengths without artifact evidence.

## Education Or Training

- Positioning: educator or enablement specialist who turns complex material into learnable workflows.
- Section order: Summary, Teaching Skills, Experience, Learning Artifacts, Education.
- Proof sequence: audience, learning objective, scaffold or rubric, learner or operational outcome.
- Avoid: unsupported learner counts, generic teaching philosophy.

## Hybrid Candidate Rule

For hybrid candidates, choose one primary positioning for the target role. Use secondary strengths as supporting evidence, not competing identities.

Prompt:

```text
The target role is [role]. The candidate's strongest supported center of gravity is [primary positioning]. Adjacent strengths are [secondary strengths]. Build the resume around the primary positioning and use adjacent strengths only where they improve fit.
```
