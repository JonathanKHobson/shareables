# Cover Letter Patterns

Use these patterns to choose the right cover-letter move instead of rewriting everything as generic enthusiasm.

## Hook -> Proof -> Bridge -> Close

Default cover-letter arc:

1. Hook: name a role-specific problem, team need, company signal, or reader-relevant question.
2. Proof: show one compact evidence-backed story.
3. Bridge: connect the proof to the role, company, team, or mission.
4. Close: offer a low-friction next step.

## Why Them, Why You, Why Now

Use this pattern when the user needs a complete letter:

- Why Them: what is specific about the role, team, product, mission, or problem.
- Why You: what evidence makes the candidate useful for that context.
- Why Now: why this match makes sense at this moment.

If "Why Them" is unsupported, write `[MISSING INFO: verified company signal]` instead of inventing admiration.

## One-Proof Rule

A cover letter should not repeat the full resume. Use one strong proof story, or two brief supporting proof points at most.

Use this pattern when a draft lists too many capabilities.

## Evidence-First Persuasion

Persuasion comes from proof, not intensity.

Strong cover-letter claims usually include:

- role problem
- candidate action
- artifact, method, or decision
- result, learning, or risk reduced
- relevance to the target role

## Company-Fit Guard

Company-specific language is high-risk unless supplied by the user or verified from a source.

Safe move:

```text
Your description of [role need] stood out because it matches my work in [supported evidence].
```

Unsafe move:

```text
I have always admired your mission and culture.
```

## Manual-Send Boundary

For referral or outreach-style letters, keep the ask low-pressure. Do not imply obligation, closeness, or automatic sending.

## Anti-Overfit Check

After tailoring a letter, ask:

- Did we use only company details the user supplied or confirmed?
- Did we preserve the candidate's real evidence?
- Would the candidate be comfortable defending every claim in an interview?
- Did the letter become clearer, or only more flattering?
