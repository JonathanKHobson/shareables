# Hooks And Openings

A strong cover-letter opening makes the reader understand why this letter exists for this role.

## Opening Rules

- Do not default to "I am writing to apply."
- Start with a role problem, company signal, product challenge, audience need, referral context, or mission fit.
- Keep the first paragraph short.
- Do not invent admiration or company facts.
- If company context is missing, use the job description's role problem.

## Hook Types

### Role-Problem Hook

Use when the job description clearly names a problem.

```text
Your posting points to a familiar challenge: [role problem]. My work in [supported evidence area] has focused on turning that kind of ambiguity into [outcome].
```

### Company-Signal Hook

Use only when the user supplies a verified company signal.

```text
[Verified company signal] stood out because it connects directly to my experience with [supported evidence].
```

### Referral Hook

Use when there is a real relationship.

```text
[Contact name] suggested I look at the [role] opening because it connects with my work in [supported evidence].
```

### Mission-Fit Hook

Use only when the mission fit is specific and verified.

```text
The emphasis on [verified mission or product signal] is what drew me to this role. My background in [supported evidence] would let me contribute to that work through [contribution].
```

### Candidate-Strength Hook

Use when the job is broad and company details are thin.

```text
I am interested in this role because it calls for [target capability], which matches my experience [specific supported proof].
```

## Repair Generic Openings

Weak:

```text
I am writing to express my interest in the open position at your company.
```

Stronger:

```text
Your posting centers on [role need], and my recent work has focused on [supported action] for [audience or business problem].
```

## Hook Output Contract

```markdown
## Best Hook
[Opening]

## Alternatives
1. [Opening]
2. [Opening]

## Support Check
- Verified target signal:
- Candidate evidence used:
- Needs verification:
```
