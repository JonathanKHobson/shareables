# Cover Letter Quality Rubric

Use this rubric for cover-letter audits and revision passes.

## Rating Scale

- 4: Strong. Ready for final human review.
- 3: Good. Needs light tightening.
- 2: Mixed. Usable, but important weaknesses remain.
- 1: Weak. Major rewrite needed.
- 0: Blocked. Missing core information or contains unsafe claims.

## Criteria

### Target Specificity

The letter clearly reflects the target role and application context.

Check:

- The opening is specific.
- The role problem is visible.
- Company-specific claims are supported or marked missing.
- Referral, cold application, or mission-fit context is handled correctly.

### Proof Strength

The letter uses evidence rather than adjectives.

Check:

- One or two proof stories carry the letter.
- Proof includes action, artifact, decision, result, or scope.
- Metrics are verified or flagged.
- Claims do not imply unsupported ownership or seniority.

### Persuasive Arc

The letter moves cleanly from hook to proof to fit to close.

Check:

- The letter is not a resume summary in paragraph form.
- Each paragraph has a job.
- The close is confident and low-pressure.
- The letter does not over-explain.

### Voice And Tone

The letter sounds human, specific, and professional.

Check:

- Tone is warm without being gushy.
- Language is direct and grounded.
- Generic enthusiasm is replaced with role-specific reasoning.
- The letter avoids over-polished AI phrasing.

### Integrity And Defensibility

The candidate can defend every line.

Check:

- No invented company research.
- No reused praise from unrelated old letters.
- No unsupported credentials, metrics, tools, clients, or relationships.
- Missing information remains visible.

## Audit Output

Use this compact format:

```markdown
## Cover Letter Health Snapshot
- Target specificity: [0-4]
- Proof strength: [0-4]
- Persuasive arc: [0-4]
- Voice and tone: [0-4]
- Integrity: [0-4]
- Top priority:

## Highest-Impact Fixes
1. [Fix]
2. [Fix]
3. [Fix]

## Do Not Change Yet
- [Anything that is already working or should not be broadened]
```
