# Proof Paragraphs

A proof paragraph is the center of the cover letter. It should make the candidate's fit believable without repeating the whole resume.

## Proof Paragraph Formula

```text
In [context], I [action/artifact/method] to address [problem], which led to [result, decision, learning, or risk reduction]. That experience maps to this role because [role relevance].
```

## What Counts As Proof

- A project, initiative, or case.
- A method applied with judgment.
- A decision influenced.
- A workflow improved.
- An artifact created.
- A measurable or observable outcome.
- A constraint handled well.

## What Does Not Count

- A list of tools without a decision.
- A generic trait.
- Unverified company admiration.
- A metric that is not in supplied evidence.
- A responsibility that does not show action.

## Compression Rules

- Use one proof story when possible.
- Use two proof points only when the role has two distinct centers.
- Keep the paragraph tight enough to read quickly.
- Prefer one vivid example over a broad list.

## Rewrite Patterns

### Resume Bullet To Proof Paragraph

Input:

```text
Improved onboarding workflow by standardizing documentation and clarifying handoffs.
```

Output:

```text
In a recent workflow project, I standardized documentation and clarified handoffs so the team could move through onboarding decisions with less ambiguity. That kind of evidence-to-execution work is directly relevant to a role focused on improving operational clarity.
```

### Unsupported Metric To Safe Proof

Unsafe:

```text
I improved efficiency by 60%.
```

Safe when the number is not verified:

```text
I improved process consistency by documenting repeatable steps, clarifying ownership, and reducing the amount of manual interpretation needed during handoffs.
```

## Proof Output Contract

```markdown
## Proof Paragraph
[Paragraph]

## Support Check
- Supplied evidence used:
- Needs verification:
- Avoid saying:
```
