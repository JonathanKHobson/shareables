# Company Fit And Research

Company fit is powerful when it is specific and verified. It is risky when it is generic, copied from an old letter, or invented.

## Company-Fit Rules

- Use company research only when the user supplies it or the host has verified it within the task.
- Do not invent mission, product, culture, values, team priorities, or hiring-manager needs.
- Do not reuse target-company praise from another application.
- If a company signal is missing, write `[MISSING INFO: verified company signal]`.
- Use the job description's role problem when company research is unavailable.

## Safe Company Signals

- A specific product, service, audience, or market.
- A stated role responsibility.
- A team priority from the job description.
- A verified mission or program.
- A real referral or conversation.
- A public article, page, or source the user provides.

## Unsafe Company Signals

- "I have always admired your company."
- "Your culture is a perfect fit."
- "Your mission deeply resonates with me."
- "I know your team needs..."
- Praise copied from an unrelated letter.

## Company-Fit Audit

Use this check:

```markdown
## Company-Fit Audit
- Verified company signals:
- Unsupported company claims:
- Safe role-problem substitute:
- Missing info:
- Rewrite:
```

## Safe Substitute Pattern

When company research is absent:

```text
What stands out in the role description is the need for [role problem]. My experience with [supported evidence] maps directly to that need.
```
