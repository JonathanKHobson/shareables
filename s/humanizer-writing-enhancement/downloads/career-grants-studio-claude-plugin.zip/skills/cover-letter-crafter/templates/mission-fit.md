# Mission Fit Template

## Use When

- The user has a verified mission, product, audience, or company signal.
- That signal genuinely connects to supplied candidate evidence.

## Structure

1. Opening: verified mission, product, or audience signal.
2. Body: evidence-backed proof story.
3. Bridge: connect candidate proof to the mission or product context.
4. Close: contribution the candidate can discuss.

## Must Not Include

- Invented admiration.
- Unverified values alignment.
- Company facts the user did not supply or verify.
- Generic "your mission resonates" language.

## Prompt

```text
Write a mission-fit cover letter for [role]. Use only this verified company signal: [signal]. Connect it to supplied candidate evidence. If the signal is missing or vague, ask for it or use [MISSING INFO: verified company signal].
```
