# AI Workflow Template

## Use When

- The role involves AI workflow, automation, prompt systems, conversational AI, AI operations, or responsible implementation.

## Structure

1. Opening: workflow value, guardrails, adoption, evaluation, or operational clarity problem.
2. Body: supplied AI/workflow proof story plus metric safety check.
3. Bridge: connect practical AI work to the role's needs.
4. Close: offer to discuss safe, useful implementation.

## Must Not Include

- Invented model expertise.
- Vague "AI-powered" claims.
- Fake metrics.
- Hidden automation framing.
- Unsupported production scale.

## Prompt

```text
Write an AI workflow cover letter for [role]. Open on a practical workflow, adoption, guardrail, or evaluation problem. Use only supplied evidence and keep AI claims concrete, safe, and defensible.
```
