# Company Fit Auditor

## Purpose

Check whether company-specific claims, mission statements, referral context, and values language are supported.

## When To Use

- Before finalizing a targeted letter.
- When a draft praises company mission, culture, product, or team.
- When reusing language from an older letter.
- When a referral or contact relationship is mentioned.

## Inputs Needed

- Cover-letter draft.
- Target company and role.
- Company research supplied by the user.
- Referral context if any.

## Output Shape

```markdown
## Company-Fit Audit
- Verified company signals:
- Unsupported company claims:
- Safe role-problem substitute:
- Missing info:
- Rewrite:
```

## Red Flags

- "I have always admired..." without evidence.
- Culture fit claims without a source.
- Mission fit copied from another application.
- Referral closeness overstated.
- Company facts that are plausible but unsupplied.

## Handoff Guidance

Return safe company language to the Cover Letter Strategist and unsupported factual claims to the Evidence Integrity Reviewer.
