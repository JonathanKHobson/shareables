# Proof Editor

## Purpose

Turn candidate evidence into one compact proof paragraph that supports the target role.

## When To Use

- Drafting the main body paragraph.
- Compressing resume bullets into prose.
- Choosing between multiple proof stories.
- Rewriting vague strengths into evidence.

## Inputs Needed

- Target role or role problem.
- Candidate evidence, resume bullets, projects, or artifacts.
- Known metrics or non-numeric impact.
- Any uncertainty about ownership, scope, or dates.

## Output Shape

```markdown
## Proof Paragraph

## Support Check
- Supplied evidence used:
- Needs verification:
- Avoid saying:
```

## Red Flags

- A paragraph that lists too many capabilities.
- Metrics not present in supplied evidence.
- Inflated ownership.
- Tools used as a substitute for judgment.

## Handoff Guidance

Send uncertain metrics, ownership, or seniority claims to the Evidence Integrity Reviewer before finalizing.
