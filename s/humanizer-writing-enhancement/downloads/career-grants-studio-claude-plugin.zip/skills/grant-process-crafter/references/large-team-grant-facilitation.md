# Large-Team Grant Facilitation

Large-team and research grants often fail from misalignment before they fail
from prose. Use facilitation artifacts to create shared vision, role clarity,
and integration before writing.

## Shared Vision Workspace

Capture:

- Central problem or research question.
- Why this funder and why now.
- Why the team or consortium is necessary.
- Each discipline, partner, or work package contribution.
- Shared outcomes and deliverables.
- What the proposal must not become.

## Integration Map

| Aim/work package | Lead | Contributors | Methods | Dependencies | Deliverables | Evidence of capacity | Risks |
| --- | --- | --- | --- | --- | --- | --- | --- |

## Meeting Cadence

- Early: vision, funder fit, roles, decision rights, work packages.
- Middle: section ownership, budget model, partner commitments, evidence.
- Late: integration, red-team review, compliance, approvals, package readiness.

Every meeting should produce at least one of: decision, artifact, owner, blocker,
or risk update.

## Governance Questions

- Who decides scope, budget changes, partner commitments, and final language?
- Who owns compliance matrix updates?
- Who owns budget/finance review?
- Who has authority to submit/certify?
- How are conflicts or late changes resolved?

## Common Large-Team Risks

- Section drafts begin before shared vision.
- Partners are named but not integrated.
- Work packages duplicate or contradict each other.
- Budget does not match responsibilities.
- Meetings create discussion without decisions.
