# Source Anchors

This skill was informed by the local Grant AI/MCP Handoff Packet and the local
Communication Story Crafter skill shape. Use these anchors as orientation, not
as a substitute for current funder instructions.

## Local Seed Packet

- `00_Executive_Handoff_and_Roadmap.docx`: grant lifecycle operating-system
  thesis, MVP modules, safeguards, and success metrics.
- `01_Grant_Lifecycle_Research_Playbook.docx`: actor map, lifecycle stages,
  prospecting, qualification, registration, NOFO analysis, timelines, and
  large-team implications.
- `02_Grant_Writing_and_Proposal_Playbook.docx`: proposal anatomy, section
  formulas, reviewer logic, funder-specific patterns, evaluation, budget, and
  red flags.
- `03_AI_MCP_Product_and_Technical_Handoff.docx`: MCP primitives, tool
  inventory, data model, human gates, and security requirements.
- `04_Templates_Checklists_Rubrics_and_Prompt_Library.docx`: prototype
  templates, scorecards, checklists, prompt workflows, and review rubrics.
- `grant_mcp_tools_schema.json`: bounded MCP-style tool inventory.
- `grant_lifecycle_state_machine.yaml`: lifecycle states and forbidden
  AI-only submission transition.

## Official Source Families To Verify Live

- Grants.gov lifecycle, registration, API, and applicant resources.
- Current funder NOFO/RFP/RFA/call documents.
- SAM.gov/UEI and portal requirements when relevant.
- 2 CFR Part 200 or other governing grant rules when federal compliance is in
  scope.
- NIH, NSF, NEH, NEA, EU/Horizon, or foundation-specific current guides when
  relevant.
- USAspending, NIH RePORTER, NSF award search, annual reports, Form 990s, or
  licensed databases for historical funder intelligence.

## Verification Policy

- For real applications, treat deadlines, eligibility, formats, budget rules,
  review criteria, portals, and post-award obligations as date-sensitive.
- Prefer official funder source text over summaries.
- Mark source date/version when known.
- Use secondary sources only as leads unless the user asks for broad research.
- If source text conflicts, pause and present the conflict.
