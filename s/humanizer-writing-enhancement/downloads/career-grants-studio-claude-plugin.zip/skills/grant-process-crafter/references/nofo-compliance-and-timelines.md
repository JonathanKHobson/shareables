# NOFO Compliance And Timelines

Turn funder instructions into an operating document before drafting. A good
compliance matrix is source-linked, owner-aware, and deadline-aware.

## Extract From The Funder Document

- Eligibility and exclusions.
- Deadlines, LOI/concept/full proposal stages, portal windows, timezone, and
  internal deadline needs.
- Award amount, duration, number of awards, cost share, reimbursement or advance
  payment patterns.
- Required narrative sections, page/word limits, formatting, filenames, and
  upload rules.
- Required forms and attachments: budgets, letters, resumes, biosketches, IRS
  letters, audits, data plans, work samples, facilities, references.
- Budget rules: allowable/unallowable costs, indirect/F&A, match, salary caps,
  equipment, travel, subawards, consultants, participant support.
- Review criteria, scoring weights, priorities, preferences, and threshold
  criteria.
- Submission mechanics: portal, workspace/package names, validation,
  resubmission policy, confirmation.
- Post-award obligations: reporting, audit, records, data sharing, closeout, and
  deliverables.

## Requirement Risk Defaults

- High: eligibility, deadline, portal, required match, required attachment,
  budget rule, certification, post-award compliance.
- Medium: page/word limits, formatting, optional-but-strategic attachments,
  ambiguous criteria.
- Low: narrative guidance that affects quality but not compliance.

## Timeline Backchain

For a standard 12-week application:

- Weeks 12-10: qualify, confirm eligibility, parse funder instructions.
- Weeks 10-8: project design, partner commitments, evidence gathering.
- Weeks 8-5: section drafts and budget.
- Weeks 5-3: review, red-team, budget/narrative alignment.
- Weeks 3-2: attachments, approvals, portal upload test.
- Final week: validation, confirmation, archive.

For a compressed application, use the same sequence with fewer artifacts. Do
not compress away eligibility, compliance, budget, or approval gates.

## Matrix Fields

Use requirement ID, source quote/location, artifact/section, owner, due date,
status, risk, and human-review notes. If the source is unclear, mark ambiguity
instead of guessing.
