# Grant Lifecycle Workflow

A useful grant assistant should support the whole lifecycle, not only grant
writing. The main value is converting messy funder instructions, applicant
context, and project ideas into an auditable sequence of decisions and
artifacts.

## Lifecycle Stages

| Stage | Work | Output | Main risk |
| --- | --- | --- | --- |
| Funding thesis | Define applicant, project, amount, timing, evidence, and outcomes. | Project/funding brief | Vague project or wrong applicant |
| Prospecting | Find likely grants through current opportunities, funder histories, peer orgs, and human signals. | Prospect list | Chasing volume over fit |
| Qualification | Check eligibility, fit, competitiveness, burden, budget, and deadline. | Fit scorecard / go-no-go | Ignoring hard blockers |
| Registration readiness | Confirm required accounts, registrations, org docs, and authority. | Readiness checklist | Portal or registration blocker |
| Opportunity analysis | Parse NOFO/RFP/RFA instructions. | Compliance matrix and timeline | Missing a requirement |
| Project design | Build need, goals, workplan, evaluation, team, partners, budget logic, and risks. | Project design canvas | Prose without feasibility |
| Drafting | Write sections from approved facts and funder criteria. | Section drafts | Generic or unsupported claims |
| Review/revision | Score against criteria, compliance, readability, budget, and evidence. | Revision queue | Review begins too late |
| Submission readiness | Assemble human handoff and approvals. | Final checklist | Unauthorized or incomplete submission |
| Award/decline | Track award terms, requests, feedback, or resubmission choices. | Award plan or feedback matrix | Losing learning or missing requests |
| Active award | Implement, report, collect evidence, manage changes, and close out. | Reporting calendar and records | Winning without compliance capacity |

## State Discipline

Do not skip from prospecting to drafting. Most grant failures come from fit,
eligibility, project design, budget coherence, or compliance misses, not from
weak sentences alone.

## Minimum Viable Grant Process

1. Define the opportunity and applicant.
2. Check hard eligibility and deadline.
3. Build a compliance matrix from source text.
4. Produce a go/no-go memo.
5. Build the project design canvas.
6. Draft only the requested section or package.
7. Run review and submission-readiness checks.
8. Hand off to authorized humans.

## Human Gates

- Eligibility confirmation before drafting.
- Go/no-go before full proposal work.
- Compliance matrix confirmation before assigning sections.
- Budget/finance review before budget narrative finalization.
- Partner/commitment approval before final review.
- Authorized representative submission/certification.
- Award-term acceptance before post-award implementation.
