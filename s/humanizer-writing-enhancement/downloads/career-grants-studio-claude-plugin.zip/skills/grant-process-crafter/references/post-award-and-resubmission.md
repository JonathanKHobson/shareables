# Post-Award And Resubmission

The grant lifecycle continues after submission. A good assistant helps preserve
learning, reporting obligations, and relationship continuity.

## If Awarded

Review the award notice and terms against proposal assumptions:

- Award amount and project period.
- Scope changes or budget revisions.
- Reporting schedule and formats.
- Deliverables, milestones, data sharing, or public acknowledgement rules.
- Spending checkpoints and approval rules.
- Change requests that require funder approval.
- Records retention and closeout obligations.

## Reporting Plan

| Report / deliverable | Due | Evidence needed | Owner | Data source | Status |
| --- | --- | --- | --- | --- | --- |

Start evidence collection at kickoff, not when the report is due.

## Closeout Checklist

- Final narrative report.
- Final financial report.
- Deliverables archived.
- Spending reconciled by authorized humans.
- Records retained according to policy.
- Lessons learned captured.
- Renewal, continuation, or relationship follow-up decided.

## If Declined

Do not treat decline as generic failure. Build a feedback matrix:

| Feedback / criterion | What it means | Proposal change | Evidence needed | Resubmit? |
| --- | --- | --- | --- | --- |

Choose between resubmission, relationship follow-up, project redesign, or
retiring the opportunity.
