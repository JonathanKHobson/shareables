# Budget Narrative And Finance Handoff

Budget work needs extra caution. This skill can help align the narrative with an
approved or draft budget, but it cannot provide legal, accounting, or
institutional finance approval.

## Budget Narrative Formula

Each cost should answer:

- What is it?
- Why is it necessary?
- How was the amount calculated?
- When will it be used?
- Which workplan activity, deliverable, or objective does it support?

## Review Checks

- Every major activity has appropriate resources.
- Every major cost appears in the workplan or project design.
- The narrative does not invent costs missing from the worksheet.
- Match/cost share assumptions are visible.
- Indirect/F&A assumptions are routed to finance or sponsored programs.
- Allowable/unallowable cost assumptions are source-linked or marked for review.
- Consultant, subaward, personnel, fringe, travel, equipment, participant
  support, and in-kind items are named accurately.

## Human Review Boundaries

Route to authorized finance/sponsored-programs review when the work touches:

- Cost allowability.
- Indirect/F&A rates.
- Salary caps, fringe, procurement, subawards, participant support, equipment,
  match, or cost share.
- Reimbursement/cash-flow requirements.
- Audit, records retention, or institutional policy.

## Safer Language

Use "requires finance review," "based on the supplied worksheet," and "pending
institutional confirmation" when a budget assumption is not approved.
