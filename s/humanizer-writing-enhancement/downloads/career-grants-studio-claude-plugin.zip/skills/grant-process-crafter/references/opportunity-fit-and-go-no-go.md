# Opportunity Fit And Go/No-Go

Grant fit is a risk gate, not a vibes check. Separate hard eligibility from
weighted strategic fit.

## Prospecting Lanes

- Open opportunity search: Grants.gov, agency portals, state/local portals,
  foundation RFP lists, EU/Horizon calls, and user-supplied links.
- Funder history: past awards, annual reports, peer organizations, Form 990s,
  USAspending, NIH RePORTER, NSF awards, or licensed databases when available.
- Human signals: program officers, prior awardees, newsletters, info sessions,
  strategic plans, and upcoming forecasts.

## Hard Gate Questions

- Is the applicant type eligible?
- Are geography, population, project type, and fiscal sponsor rules compatible?
- Are SAM/UEI or other portal registrations needed and current?
- Is the deadline realistic, including internal review and portal validation?
- Is required match/cost share feasible?
- Are activities, costs, or applicant relationships prohibited?
- Does an authorized human exist for submission/certification?

## Weighted Fit Criteria

| Criterion | What to check |
| --- | --- |
| Mission/program fit | Direct source-backed alignment with funder goals and review criteria |
| Population/geography fit | Eligible and prioritized communities, regions, or fields |
| Project type fit | Activities are allowed and desired |
| Budget fit | Amount, duration, match, indirect/F&A, cash flow, and restrictions |
| Evidence/readiness | Need data, prior results, partner commitments, docs, staffing, evaluation |
| Competitiveness | Award rate if known, likely applicant pool, past awards, relationship |
| Strategic value | Renewal, relationship, portfolio, learning, capacity, public value |
| Burden/risk | Reporting, audit, reimbursement, cash-flow, compliance, politics |

## Recommendation Labels

- `go`: hard gates pass and strategic value justifies the burden.
- `no-go`: hard gate fails or burden/fit is not worth the effort.
- `watch`: promising but not ready, invitation-dependent, or next-cycle better.
- `needs-info`: a decision-critical fact is missing.

## Anti-Patterns

- Treating award size as fit.
- Drafting before eligibility is source-checked.
- Ignoring required match until the budget phase.
- Calling a grant low-risk because the writing seems easy.
- Overriding hard blockers with enthusiasm.
