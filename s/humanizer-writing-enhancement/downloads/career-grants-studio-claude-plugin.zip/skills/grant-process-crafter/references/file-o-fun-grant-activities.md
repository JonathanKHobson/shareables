# File-O-Fun Grant Activity Adaptations

Use File-O-Fun patterns as lightweight facilitation scaffolds inside grant work.
Do not turn a grant task into a separate activity-library project.

## Useful Adaptations

| Grant need | File-O-Fun pattern | Grant adaptation |
| --- | --- | --- |
| Claim support | Evidence Confidence Grid | Sort proposal claims into sourced, user-asserted, inferred, weak, and missing. |
| Go/no-go | Weighted Decision Matrix | Compare opportunities against agreed criteria and weights. |
| Prioritization | RICE Scoring Workshop | Score prospecting or revision backlog by reach/value, impact, confidence, and effort. |
| Risk planning | Risk Matrix | Prioritize compliance, timeline, budget, partner, and delivery risks. |
| Large-team roles | DACI Decision Roles Setup | Assign driver, approver, contributors, and informed roles for grant decisions. |
| Team norms | Working Agreements Workshop | Set proposal-team expectations for drafts, comments, deadlines, and decisions. |
| Meeting repair | Meeting Reset Protocol | Fix recurring proposal meetings that are no longer producing decisions or artifacts. |
| Evidence review | Research Playback With Evidence Tags | Share project evidence while preserving source quality and caveats. |
| Project interviews | Interview Guide Dry Run | Test project-design interview questions before stakeholder or partner sessions. |
| Deadline pressure | Deadline Backchain Micro-Map | Backchain from submission through approvals, budget, attachments, and drafts. |
| Scope control | 1-3-5 Scope Clamp | Identify 1 must-ship artifact, 3 supporting tasks, and 5 parking-lot items. |

## Facilitation Guardrails

- Keep activities artifact-centered, not personality-centered.
- Avoid public critique of individuals; critique claims, drafts, risks, and
  decisions.
- Add psychological-safety notes for feedback, partner power dynamics, community
  commitments, or vulnerable populations.
- Capture the artifact at the end: decision receipt, revision queue, source map,
  missing-info list, or owner table.
