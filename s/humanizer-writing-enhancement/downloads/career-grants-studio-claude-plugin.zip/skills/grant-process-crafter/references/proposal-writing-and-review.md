# Proposal Writing And Review

Grant writing is evidence design. Style matters, but it should clarify the
project-design argument.

## Reviewer Reading Assumptions

- The reviewer is smart, tired, and reading under time pressure.
- Headings, topic sentences, and visible alignment to criteria matter.
- Funder language helps when it is accurate and specific; parroting weakens
  credibility.
- Specific proof beats generic passion.

## Universal Proposal Anatomy

- Executive summary or abstract.
- Need, problem, or significance.
- Goals, objectives, or specific aims.
- Methods, project design, or workplan.
- Evaluation, monitoring, learning, or assessment.
- Team, organizational capacity, and partners.
- Budget and budget narrative.
- Sustainability, dissemination, public engagement, or continuation.
- Required appendices and attachments.

## Paragraph Pattern

Use claim -> evidence -> implication:

1. Make the central claim.
2. Support it with supplied data, source text, prior outcomes, lived/community
   evidence, literature, or artifact evidence.
3. Explain why it matters for this project and this funder.

## Section Review Checklist

- Does the section answer the funder's exact question?
- Does the first paragraph state the central point?
- Are claims supported by data, citations, prior outcomes, source documents, or
  approved user facts?
- Does the section connect to review criteria and funder priorities?
- Are outcomes measurable and linked to activities and budget?
- Is the prose specific, concise, and skimmable?
- Does the section avoid inflated promises and invented evidence?
- Does the section comply with word/page/format requirements?

## Reviewer Simulator Criteria

Score only against supplied or source-derived criteria when possible. If using a
generic rubric, label it generic. Useful generic criteria include funder
alignment, need/significance, project design, outcomes/evaluation,
team/capacity, budget coherence, compliance, and readability/persuasion.
