# Project Design And Evaluation

A grant proposal succeeds when the project is credible. Drafting should follow
project design, not replace it.

## Project Design Canvas

- Need: the problem, opportunity, community, field, or system gap.
- Funder alignment: exact funder goals, priorities, review criteria, or past
  giving/funding patterns.
- Solution: activities, methods, work packages, curriculum, intervention,
  research design, production, or services.
- Beneficiaries/users: who benefits, how they are reached, and how access,
  inclusion, and consent are handled.
- Objectives: measurable changes by date, population/system, and indicator.
- Outputs: countable products or activities.
- Outcomes: short-term and intermediate changes.
- Evaluation: questions, indicators, data sources, collection cadence,
  responsible roles, analysis, and use of findings.
- Team/capacity: staff, partners, facilities, credentials, prior results, and
  governance.
- Budget logic: resources required for the workplan.
- Risks: recruitment, data, timeline, partner, cost, compliance, or delivery
  risks and mitigation.
- Sustainability: what lasts after the grant and how it is maintained.

## Objective Formula

By `[date]`, `[applicant/team]` will `[action]` for `[population/system]`,
resulting in `[measurable change]` as measured by `[indicator/source]`.

## Evaluation Paragraph Formula

We will evaluate `[evaluation question]` using `[data sources/tools]` collected
`[frequency]` by `[responsible role]`. Findings will be reviewed `[cadence]`
with `[stakeholders]` and used to `[improve implementation/report/share
learning]`.

## Common Design Risks

- Objectives describe activities rather than outcomes.
- Need statement uses national data for a local project without local relevance.
- Outcomes exceed what activities can plausibly create.
- Evaluation is unresourced or disconnected from reporting.
- Partners appear in prose but not in roles, letters, or budget.
- Budget and workplan tell different stories.
