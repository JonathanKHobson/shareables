# Funder Fit Scorecard

```markdown
## Fit Scorecard
| Criterion | Weight | Score 1-5 | Evidence/source | Notes |
| --- | ---: | ---: | --- | --- |
| Hard eligibility | Gate |  |  | No-go if unmet |
| Mission alignment | 20% |  |  |  |
| Population/geography fit | 10% |  |  |  |
| Project type fit | 10% |  |  |  |
| Budget fit | 15% |  |  |  |
| Readiness | 15% |  |  |  |
| Competitiveness | 10% |  |  |  |
| Strategic value | 10% |  |  |  |
| Compliance burden/risk | 10% |  |  |  |

## Recommendation
- Go / no-go / watch / needs-info:
- Rationale:
- Missing information:
- Decision owner/date:
```
