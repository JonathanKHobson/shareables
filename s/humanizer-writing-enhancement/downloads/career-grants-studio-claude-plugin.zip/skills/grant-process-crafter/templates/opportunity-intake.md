# Opportunity Intake

```markdown
## Opportunity
- Title:
- Funder / program:
- Source URL / ID:
- Source date/version:
- Status:

## Key Terms
- Applicant eligibility:
- Geography / population:
- Project type:
- Deadline(s):
- Award amount:
- Duration:
- Cost share / match:
- Portal / submission route:

## Requirements
- Narrative sections:
- Attachments / forms:
- Budget rules:
- Review criteria:
- Post-award obligations:

## Initial Read
- Hard blockers:
- Fit signals:
- Unknowns:
- Recommended next action:
```
