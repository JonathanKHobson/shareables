# Go/No-Go Memo

```markdown
## Recommendation
- Decision:
- Confidence:
- Opportunity:
- Applicant/project:
- Deadline:

## Hard Gates
- Eligibility:
- Registration/portal:
- Budget/match:
- Deadline/readiness:
- Submission authority:

## Strategic Fit
- Funder alignment:
- Project fit:
- Evidence/readiness:
- Competitiveness:
- Relationship/portfolio value:
- Burden/risk:

## Rationale

## Missing Information

## Decision Needed From

## Next Action
```
