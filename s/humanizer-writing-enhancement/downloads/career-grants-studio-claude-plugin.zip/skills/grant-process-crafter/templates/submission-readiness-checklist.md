# Submission Readiness Checklist

```markdown
## Package Status
- Ready / not ready / needs human review:
- Highest-risk item:
- Authorized submitter:

## Checklist
| Item | Requirement/source | Status | Owner | Risk | Notes |
| --- | --- | --- | --- | --- | --- |
| Narrative sections complete |  |  |  |  |  |
| Page/word/format limits checked |  |  |  |  |  |
| Budget and budget narrative aligned |  |  |  |  |  |
| Attachments/forms present |  |  |  |  |  |
| Partner letters/MOUs reviewed |  |  |  |  |  |
| Finance/sponsored programs reviewed |  |  |  |  |  |
| Authorized representative reviewed |  |  |  |  |  |
| Portal validation checked |  |  |  |  |  |
| Submission archive plan ready |  |  |  |  |  |

## Do Not Submit Until

## Confirmation Archive Plan
```
