# Project Design Canvas

```markdown
## Project Identity
- Applicant/team:
- Project title:
- Funder/opportunity:
- Amount/period:

## Need
- Problem/opportunity:
- Population/place/field:
- Evidence:
- Why now:

## Funder Alignment
- Priority/criterion:
- How the project advances it:
- Source:

## Workplan
| Activity | Owner | Timeline | Output | Budget link | Risk |
| --- | --- | --- | --- | --- | --- |

## Objectives And Outcomes
| Objective | Output | Outcome | Indicator | Data source |
| --- | --- | --- | --- | --- |

## Evaluation
- Questions:
- Methods/data:
- Collection cadence:
- Responsible role:
- Use of findings:

## Team And Partners

## Budget Logic

## Risks And Mitigations

## Sustainability / Dissemination

## Missing Information
```
