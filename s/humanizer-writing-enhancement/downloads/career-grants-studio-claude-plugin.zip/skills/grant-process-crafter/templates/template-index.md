# Template Index

Use these templates as starting points, then adapt to the funder document,
applicant context, project facts, and evidence supplied by the user.

| Need | Template |
| --- | --- |
| Normalize a prospect | `opportunity-intake.md` |
| Score fit and readiness | `funder-fit-scorecard.md` |
| Parse requirements | `nofo-compliance-matrix.md` |
| Decide whether to pursue | `go-no-go-memo.md` |
| Design the project | `project-design-canvas.md` |
| Coordinate large teams | `large-team-integration-map.md` |
| Plan a section | `proposal-section-plan.md` |
| Review like a funder | `review-simulator-rubric.md` |
| Prepare human submission | `submission-readiness-checklist.md` |
| Plan reporting and closeout | `post-award-plan.md` |
