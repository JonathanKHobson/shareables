# NOFO Compliance Matrix

```markdown
## Compliance Matrix
| ID | Requirement text/source quote | Source location | Artifact/section | Owner | Due | Status | Risk | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| R-001 |  |  | Eligibility check |  |  | Open | High |  |
| R-002 |  |  | Narrative section |  |  | Open | Medium |  |
| R-003 |  |  | Budget + narrative |  |  | Open | High |  |
| R-004 |  |  | Attachment |  |  | Open | Medium |  |
| R-005 |  |  | Portal step |  |  | Open | High |  |

## Ambiguities For Human Review

## Timeline Risks

## Drafting Implications
```
