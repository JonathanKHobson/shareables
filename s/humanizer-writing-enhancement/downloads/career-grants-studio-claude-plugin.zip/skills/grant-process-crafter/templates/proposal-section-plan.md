# Proposal Section Plan

```markdown
## Section
- Name:
- Funder prompt/question:
- Review criterion:
- Word/page limit:
- Required source/attachment links:

## Strategy
- Central claim:
- Evidence:
- Funder language to use:
- Reader concern:
- Budget/workplan link:

## Draft Outline
1.
2.
3.

## Unsupported Claims To Avoid

## Missing Information
```
