# Post-Award Plan

```markdown
## Award / Decision Status
- Awarded / declined / pending / revision requested:
- Source document:
- Date:
- Owner:

## If Awarded
| Obligation | Due | Evidence needed | Owner | Status | Notes |
| --- | --- | --- | --- | --- | --- |

## Spending / Scope Questions

## Evidence Collection Plan

## Closeout Checklist

## If Declined
| Feedback | Meaning | Change needed | Evidence needed | Resubmit? |
| --- | --- | --- | --- | --- |

## Next Action
```
