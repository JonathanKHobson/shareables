# Large-Team Integration Map

```markdown
## Shared Vision
- Central problem:
- Funder-fit argument:
- Why this team:
- Success definition:

## Decision Roles
| Decision | Driver | Approver | Contributors | Informed |
| --- | --- | --- | --- | --- |

## Work Package / Aim Map
| Aim/work package | Lead | Contributors | Methods | Dependencies | Deliverables | Evidence of capacity | Risks |
| --- | --- | --- | --- | --- | --- | --- | --- |

## Meeting Cadence
- Next meeting purpose:
- Required pre-work:
- Decisions needed:
- Artifacts due:

## Integration Risks

## Partner Commitment Gaps
```
