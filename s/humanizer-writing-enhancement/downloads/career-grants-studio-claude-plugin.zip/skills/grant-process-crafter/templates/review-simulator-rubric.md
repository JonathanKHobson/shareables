# Review Simulator Rubric

```markdown
## Review Snapshot
- Proposal/section:
- Funder criteria used:
- Overall readiness:

## Scores
| Criterion | Score 1-5 | Rationale | Evidence | Revision action |
| --- | ---: | --- | --- | --- |
| Funder alignment |  |  |  |  |
| Need/significance |  |  |  |  |
| Project design |  |  |  |  |
| Outcomes/evaluation |  |  |  |  |
| Team/capacity |  |  |  |  |
| Budget coherence |  |  |  |  |
| Compliance |  |  |  |  |
| Readability/persuasion |  |  |  |  |

## Top Risks

## Prioritized Revision Queue

## Human Review Needed
```
