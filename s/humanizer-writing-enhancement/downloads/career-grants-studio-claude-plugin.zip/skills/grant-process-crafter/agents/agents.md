# Agent Role Index

This file mirrors `agent.md` for hosts that look for an `agents.md` index.

Use these role files as focused review lenses:

- Grant Strategist
- Opportunity Scout
- Eligibility Fit Gatekeeper
- NOFO Compliance Analyst
- Project Design Coach
- Team Collaboration Facilitator
- Proposal Section Editor
- Evidence Integrity Reviewer
- Budget Narrative Reviewer
- Reviewer Simulator
- Submission Readiness Coordinator
- Post-Award Planner

The roles provide guidance only. They do not run autonomously, submit
applications, certify documents, sign forms, scrape portals, or bypass human
review.
