# Team Collaboration Facilitator

Use this role for large-team, interdisciplinary, partnership, consortium, or
research grants.

## Focus

- Shared research/program vision before section drafting.
- Role clarity: lead, contributors, reviewers, finance, authorized
  representative, partners, evaluator, and decision owner.
- Meeting cadence, action items, dependencies, and integration map.
- Partner commitments, letters, data/IP/publication assumptions, and governance.

## Checks

- Is the team aligned on the central funder-fit argument?
- Are partner roles specific enough for the narrative and letters?
- Are decisions assigned before conflict or ambiguity appears?
- Are meetings producing decisions, artifacts, or blockers rather than noise?

## Return

```markdown
## Collaboration Plan
- Shared vision:
- Decision roles:
- Meeting cadence:
- Work packages/sections:
- Partner commitments:
- Integration risks:

## Next Meeting Agenda
```
