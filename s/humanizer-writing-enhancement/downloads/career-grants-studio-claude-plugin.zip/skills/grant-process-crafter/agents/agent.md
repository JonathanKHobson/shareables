# Grant Process Crafter Agents

These are prompt-role files, not executable agents. Use them when a grant task
benefits from a focused specialist lens.

## Available Roles

- `grant-strategist.md`: lifecycle stage, scope, user goal, and next deliverable.
- `opportunity-scout.md`: search strategy, prospect fields, and source coverage.
- `eligibility-fit-gatekeeper.md`: hard blockers, fit scoring, and go/no-go memo.
- `nofo-compliance-analyst.md`: requirements, deadlines, attachments, and compliance matrix.
- `project-design-coach.md`: project design, outcomes, evaluation, risks, and feasibility.
- `team-collaboration-facilitator.md`: shared vision, role clarity, meetings, partners, and integration.
- `proposal-section-editor.md`: funder-aligned section drafting and revision.
- `evidence-integrity-reviewer.md`: source support, provenance, missing proof, and overclaiming.
- `budget-narrative-reviewer.md`: budget narrative coherence and finance-review boundaries.
- `reviewer-simulator.md`: rubric scoring, red-team review, and revision queue.
- `submission-readiness-coordinator.md`: final checklist, approvals, and human submission handoff.
- `post-award-planner.md`: award terms, reporting calendar, evidence plan, closeout, and resubmission.

## Coordination Pattern

For an opportunity decision:

1. Opportunity Scout normalizes the opportunity and source coverage.
2. Eligibility Fit Gatekeeper separates hard blockers from weighted fit.
3. Grant Strategist produces the go/no-go recommendation.
4. Evidence Integrity Reviewer checks source support and missing proof.

For a NOFO/RFP-to-draft workflow:

1. NOFO Compliance Analyst extracts the compliance matrix and timeline.
2. Project Design Coach builds or repairs the project design.
3. Budget Narrative Reviewer checks budget/workplan coherence.
4. Proposal Section Editor drafts or revises sections.
5. Reviewer Simulator and Evidence Integrity Reviewer produce the revision queue.

For a large-team proposal:

1. Team Collaboration Facilitator creates shared vision, roles, and meeting cadence.
2. Project Design Coach maps aims/work packages, outcomes, and dependencies.
3. NOFO Compliance Analyst tracks requirements and owners.
4. Grant Strategist keeps the proposal moving toward the next decision gate.

## Handoff Rule

Each role should return concise findings and specific edits or next actions. Do
not produce parallel full proposals unless the user explicitly asks for variants.
