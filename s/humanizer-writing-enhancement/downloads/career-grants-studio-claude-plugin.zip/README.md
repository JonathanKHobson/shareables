# Career Grants Studio

Generated: 2026-07-22T06:15:25Z
Format: claude-code

Resume, cover letter, portfolio, grant, and career/application communication skills.

## Skills

- `resume-crafter`
- `cover-letter-crafter`
- `portfolio-crafter`
- `grant-process-crafter`

## Related Plugins And Adjacent Skills

- `marketing-social-studio`: `communication-story-crafter`, `marketing-strategy-operator`
- `mcp-workbench`: `job_application_compass`
- `media-io-toolkit`: `doc`, `pdf`

## Adjacent MCP Keys

- `job_application_compass`

MCP keys are documented adjacency, not automatic startup. This plugin does not
enable MCP servers by itself unless an `.mcp.json` is explicitly present.

## Starter Prompts

- Target this resume.
- Draft a cover letter.
- Package a grant application plan.

## Install Notes

- Claude Code: load the plugin root with `claude --plugin-dir <plugin-root>` or the generated zip.
- Codex: use the generated `.codex-plugin/plugin.json` bundle or the workspace marketplace export.
- Canonical skill sources remain outside this bundle. Rebuild from source rather than editing generated copies.
