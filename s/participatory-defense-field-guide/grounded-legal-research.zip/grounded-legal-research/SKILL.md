---
name: grounded-legal-research
description: Conduct grounded U.S. legal research using connected CourtListener and legal-data MCPs. Use for questions involving statutes, regulations, case law, citations, legal authority, or legal research memos where jurisdiction, live sources, precise quotations, and uncertainty need to be handled carefully.
---

# Grounded Legal Research

Research law as a source-backed information task, not legal advice. Do not answer from memory when a connected legal MCP can answer the question.

## Workflow

1. Determine jurisdiction before researching. State the jurisdiction, court system, and time period that govern the question. If material and unknown, ask one concise clarifying question; otherwise make a narrow, labeled assumption.
2. Search connected legal MCPs first. Use CourtListener for case law and citation analysis; use the official GovInfo MCP for the U.S. Code, CFR, public laws, and official records; use US Legal MCP for Federal Register material and supplementary federal-legislation discovery. Do not treat a bill, press release, or a search snippet as controlling law.
3. Separate authority types:
   - **Statutes:** use the codified U.S. Code or an official public-law text; identify title, section, and currency.
   - **Regulations:** use the CFR or agency rule/publication; identify title/part/section and effective status.
   - **Case law:** identify the court, date, reporter or neutral citation, precedential status when known, and a link to the opinion.
4. Prefer official primary sources: Congress.gov, uscode.house.gov, GovInfo, eCFR/Federal Register, official court opinions. CourtListener is a strong free case-law source and citation check, but verify controlling text against an official source when available.
5. Retrieve the authority itself before quoting. Quote only the exact language returned by the source; preserve omissions with ellipses and label pinpoint locations. Never reconstruct language or cite an authority that the tools did not return.
6. Cite every legal authority used immediately after the proposition it supports. Include a stable URL plus conventional legal citation where the source supplies it. Identify whether a citation was verified by CourtListener or merely retrieved.
7. Reconcile conflicts. When sources disagree, prefer controlling and more current authority, state the conflict, and explain what could not be resolved. Say when coverage, currency, or jurisdiction is uncertain.

## Research Output

Use this concise structure unless the user asks for a different format:

```markdown
**Jurisdiction and scope:** ...

**Short answer:** ...

**Authorities:**
- Statute: ...
- Regulation: ...
- Case law: ...

**Analysis:** ...

**Uncertainty / verification notes:** ...

*This is informational research, not legal advice. Consult a qualified attorney for advice about your circumstances.*
```

## Non-Negotiables

- Never fabricate a case name, court, reporter cite, section number, quotation, holding, date, or URL.
- Never imply a nonbinding source is controlling.
- Do not give individualized legal advice, predict an outcome with certainty, or omit the informational-not-legal-advice reminder.
- If MCP access fails, say what could not be verified and offer only clearly labeled general information; do not fill the gap with invented authority.
