# Privacy, Confidentiality, and Evidence Checklist

## Before using an AI tool

- Use a fictional scenario for public demonstrations.
- Work from a copy, never the original.
- Remove or replace names, addresses, exact birth dates, phone numbers, email addresses, case numbers, account numbers, biometric identifiers, and government identifiers.
- Remove metadata when appropriate, but preserve an untouched original separately.
- Ask whether the document is sealed, protected, confidential, privileged, subject to a discovery order, or restricted by law.
- Check the tool's retention, training, sharing, and connector permissions.
- Use the least-powerful permissions: read-only, minimum sources, no automatic sending or filing.

## Do not upload without qualified review

- privileged attorney-client communications or attorney work product;
- sealed or expunged records;
- grand-jury material;
- protected criminal discovery;
- unredacted information about minors, survivors, witnesses, jurors, confidential informants, or medical patients;
- immigration identifiers, full Social Security numbers, financial credentials, passwords, API keys, or recovery codes;
- contraband imagery or unlawfully possessed material;
- information that could expose someone to retaliation, arrest, deportation, stalking, harassment, or physical harm.

## Evidence preservation

- Keep the original file or device unchanged.
- Record where the item came from, when it was obtained, and who handled it.
- Do not crop, annotate, enhance, transcode, rename deceptively, or overwrite the original.
- Create a working copy for OCR, transcription, redaction, annotation, or summarization.
- Label AI-generated text as a derivative aid, not evidence.
- Compare OCR and transcripts against the original; mark uncertainty rather than guessing.
- Do not delete, hide, alter, fabricate, or encourage destruction of potential evidence.
- Do not contact or coach witnesses based on AI output.

## Confidentiality reality check

Do not assume:

- an AI conversation is attorney-client privileged;
- a community meeting creates privilege;
- a free account guarantees no retention;
- an MCP connector only sees the single sentence you typed;
- deleting a chat deletes all logs or downstream copies;
- a redacted screen image has had its metadata or hidden text removed.

When privilege or confidentiality matters, ask the person's lawyer what may be shared and through which approved system.

## Safer document workflow

1. Preserve original.
2. Make a working copy.
3. Remove hidden text, comments, tracked changes, layers, and metadata where appropriate.
4. Redact—do not merely draw a black rectangle over text.
5. Verify the redaction cannot be copied, searched, or revealed.
6. Upload only the minimum pages and facts necessary.
7. Delete local temporary copies when safe and permitted, while preserving required records.
8. Keep a source and handling log.
