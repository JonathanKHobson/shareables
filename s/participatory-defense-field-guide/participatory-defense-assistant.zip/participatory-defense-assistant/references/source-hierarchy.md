# Legal Source Hierarchy and Verification Guide

## The core rule

The model is not the source. A connector is not the source. A summary is not the source. The source is the actual, applicable legal text or filed document.

## Authority ladder

### 1. The person's own case documents

Examples: signed order, notice, complaint, indictment, citation, summons, docket entry, minute entry, release condition, or filed motion.

These establish what the court or agency has actually done in the specific matter. Verify authenticity, date, page count, and whether a later order supersedes them.

### 2. Controlling primary law

Examples: constitution, enacted statute, codified regulation, court rule, binding appellate opinion, standing order, local rule, or administrative decision.

Check jurisdiction, court hierarchy, effective date, amendment history, and later treatment.

### 3. Official government publication or repository

Examples: official court website, legislature, agency, GovInfo, eCFR, Federal Register, Congress.gov, state code portal, or official form library.

Official self-help pages can be excellent procedural guidance, but distinguish guidance from binding law.

### 4. Source-grounded legal databases

Examples: CourtListener, a public law library database, or a licensed citator available through a library.

Open the underlying opinion or document. Verify quotations and currentness; database labels are not a substitute for legal judgment.

### 5. Trusted explanatory sources

Examples: legal-aid organizations, public law libraries, bar associations, recognized treatises, or law-school clinics.

Use for orientation and search terms. Confirm action-critical points against primary or official sources.

### 6. Commentary and media

Examples: articles, blogs, videos, social posts, discussion forums, or advocacy materials.

Potentially useful for context, lived experience, and issue spotting. Not sufficient authority for a filing or rights decision.

### 7. Model memory

Use only to generate possible keywords, source types, and questions. Label everything as unverified until independently sourced.

## Distinctions that must remain visible

- **Binding vs. persuasive authority**
- **Federal vs. state vs. tribal vs. territorial vs. local law**
- **Trial vs. appellate authority**
- **Published/precedential vs. unpublished/nonprecedential opinion**
- **Enacted law vs. introduced bill**
- **Current regulation vs. proposed rule or agency guidance**
- **Law in effect today vs. law in effect on the relevant event date**
- **Official form vs. unofficial sample**
- **Legal rule vs. a court's factual finding**
- **Holding vs. dicta**
- **Case existence vs. quotation accuracy vs. later treatment**

## Citation verification checklist

1. Does the authority exist?
2. Is the title/case name accurate?
3. Is the citation accurate?
4. Does the quoted language appear exactly at the pinpoint?
5. Is the court/agency correct?
6. Is the jurisdiction relevant?
7. Is the authority binding, persuasive, or merely explanatory?
8. Was the law in effect on the relevant date?
9. Has it been amended, repealed, vacated, reversed, superseded, or criticized?
10. Does a local rule, standing order, or later case alter the result?
11. Is there a newer official version?
12. Has a qualified human reviewed action-critical use?
