# Legal Research and Verification Log

## Matter scope

- Matter label:
- Jurisdiction:
- Court/agency:
- Matter type:
- Procedural stage:
- Relevant event date:
- Current date:
- Counsel/legal-aid contact:
- Immediate human-review issue:

## Search log

| Date/time | Research question | Search terms | Tool/source searched | Results found | Follow-up needed |
|---|---|---|---|---|---|
| | | | | | |

## Authority verification

| Proposition | Authority and citation | Issuer/jurisdiction | Decision/effective date | Pinpoint and exact text checked | Later treatment/currentness checked | Official source opened | Status | Reviewer |
|---|---|---|---|---|---|---|---|---|
| | | | | | | | NEEDS VERIFICATION | |

## Failed or ambiguous searches

| Question | Where searched | What was not found | Why ambiguity matters | Who should verify |
|---|---|---|---|---|
| | | | | |

## Action gates

| Proposed action | Source of requirement | Deadline source | Human review required | Completed by/date |
|---|---|---|---|---|
| | | | Yes | |
